using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Farahi.Tests
{
    public class BookingsTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;
        private readonly JsonSerializerOptions _json = new() { PropertyNameCaseInsensitive = true };

        public BookingsTests(WebApplicationFactory<Program> factory) => _client = factory.CreateClient();

        // ──── Bookings ────

        [Fact]
        public async Task Bookings_Create_AsCustomer_Returns201()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var futureDate = DateTime.Today.AddDays(60);

            var res = await AuthPost(token, "api/bookings", new
            {
                ServiceID = 2,
                EventDate = futureDate.ToString("yyyy-MM-dd"),
                Notes = "Test booking"
            });

            // Might be 201 (created) or 409 (date taken) depending on test run order
            Assert.True(res.StatusCode == HttpStatusCode.Created || res.StatusCode == HttpStatusCode.Conflict);
        }

        [Fact]
        public async Task Bookings_Create_WithoutAuth_Returns401()
        {
            var res = await _client.PostAsJsonAsync("api/bookings", new { ServiceID = 1, EventDate = "2026-12-01" });
            Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
        }

        [Fact]
        public async Task Bookings_GetMy_AsCustomer_ReturnsList()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthGet(token, "api/bookings/my");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        [Fact]
        public async Task Bookings_GetProvider_AsProvider_ReturnsList()
        {
            var token = await LoginAs("ahmed@example.com", "Ahmed@123");
            var res = await AuthGet(token, "api/bookings/provider");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<List<BookingData>>>(res);
            Assert.True(body.Data!.Count > 0);
        }

        [Fact]
        public async Task Bookings_GetById_Returns200()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthGet(token, "api/bookings/1");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── Reviews ────

        [Fact]
        public async Task Reviews_Create_ForNonCompletedBooking_Returns400()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            // Booking 1 هو Confirmed مش Completed
            var res = await AuthPost(token, "api/reviews", new { BookingID = 1, Rating = 5, Comment = "Great!" });
            // ممكن يكون 400 (مش مكتمل) أو 409 (اتقيّم قبل كده)
            Assert.True(res.StatusCode == HttpStatusCode.BadRequest || res.StatusCode == HttpStatusCode.Conflict);
        }

        // ──── Notifications ────

        [Fact]
        public async Task Notifications_GetMine_ReturnsList()
        {
            var token = await LoginAs("ahmed@example.com", "Ahmed@123");
            var res = await AuthGet(token, "api/notifications");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        [Fact]
        public async Task Notifications_UnreadCount_ReturnsNumber()
        {
            var token = await LoginAs("ahmed@example.com", "Ahmed@123");
            var res = await AuthGet(token, "api/notifications/unread-count");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<UnreadData>>(res);
            Assert.True(body.Data!.Count >= 0);
        }

        [Fact]
        public async Task Notifications_MarkAllRead_Returns200()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthPut(token, "api/notifications/read-all", null);
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── Favorites ────

        [Fact]
        public async Task Favorites_AddAndCheck_Works()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");

            // إضافة
            var addRes = await AuthPost(token, "api/favorites/3", null);
            Assert.True(addRes.StatusCode == HttpStatusCode.Created || addRes.StatusCode == HttpStatusCode.OK);

            // التحقق
            var checkRes = await AuthGet(token, "api/favorites/check/3");
            Assert.Equal(HttpStatusCode.OK, checkRes.StatusCode);
            var body = await Deserialize<Wrapper<FavCheckData>>(checkRes);
            Assert.True(body.Data!.IsFavorite);
        }

        [Fact]
        public async Task Favorites_GetMine_ReturnsList()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthGet(token, "api/favorites");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        [Fact]
        public async Task Favorites_Remove_Returns200()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");

            // أضف أولاً عشان نتأكد إنها موجودة
            await AuthPost(token, "api/favorites/5", null);

            var req = new HttpRequestMessage(HttpMethod.Delete, "api/favorites/5");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var res = await _client.SendAsync(req);

            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── Bug Reports ────

        [Fact]
        public async Task BugReports_Create_Returns201()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthPost(token, "api/bugreports", new
            {
                Title = "مشكلة في الحجز",
                Description = "الصفحة مش بتحمل"
            });

            Assert.Equal(HttpStatusCode.Created, res.StatusCode);
        }

        [Fact]
        public async Task BugReports_GetMine_ReturnsList()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthGet(token, "api/bugreports/my");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        [Fact]
        public async Task BugReports_GetAll_AsAdmin_ReturnsList()
        {
            var token = await LoginAs("admin@farahi.com", "Admin@123");
            var res = await AuthGet(token, "api/bugreports");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        [Fact]
        public async Task BugReports_GetAll_AsCustomer_Returns403()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthGet(token, "api/bugreports");
            Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
        }

        // ──── Dashboard ────

        [Fact]
        public async Task Dashboard_Provider_Returns200()
        {
            var token = await LoginAs("ahmed@example.com", "Ahmed@123");
            var res = await AuthGet(token, "api/dashboard/provider");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<ProviderDashData>>(res);
            Assert.True(body.Data!.TotalServices > 0);
            Assert.True(body.Data.TotalEarnings >= 0);
        }

        [Fact]
        public async Task Dashboard_Admin_Returns200()
        {
            var token = await LoginAs("admin@farahi.com", "Admin@123");
            var res = await AuthGet(token, "api/dashboard/admin");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<AdminDashData>>(res);
            Assert.True(body.Data!.TotalUsers > 0);
            Assert.True(body.Data.TotalServices > 0);
        }

        [Fact]
        public async Task Dashboard_Admin_AsCustomer_Returns403()
        {
            var token = await LoginAs("omar@example.com", "Omar@123");
            var res = await AuthGet(token, "api/dashboard/admin");
            Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
        }

        // ──── Helpers ────

        private async Task<string> LoginAs(string email, string password)
        {
            var res = await _client.PostAsJsonAsync("api/auth/login", new { Email = email, Password = password });
            var body = await Deserialize<Wrapper<AuthData>>(res);
            return body.Data!.AccessToken;
        }

        private async Task<HttpResponseMessage> AuthGet(string token, string url)
        {
            var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _client.SendAsync(req);
        }

        private async Task<HttpResponseMessage> AuthPost(string token, string url, object? body)
        {
            var req = new HttpRequestMessage(HttpMethod.Post, url);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            if (body != null) req.Content = JsonContent.Create(body);
            return await _client.SendAsync(req);
        }

        private async Task<HttpResponseMessage> AuthPut(string token, string url, object? body)
        {
            var req = new HttpRequestMessage(HttpMethod.Put, url);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            if (body != null) req.Content = JsonContent.Create(body);
            return await _client.SendAsync(req);
        }

        private async Task<T> Deserialize<T>(HttpResponseMessage res)
        {
            var json = await res.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<T>(json, _json)!;
        }

        // ──── DTOs ────
        private class Wrapper<T> { public bool Success { get; set; } public T? Data { get; set; } }
        private class AuthData { public string AccessToken { get; set; } = ""; }
        private class BookingData { public int BookingID { get; set; } public string Status { get; set; } = ""; }
        private class UnreadData { public int Count { get; set; } }
        private class FavCheckData { public bool IsFavorite { get; set; } }
        private class ProviderDashData { public int TotalServices { get; set; } public decimal TotalEarnings { get; set; } }
        private class AdminDashData { public int TotalUsers { get; set; } public int TotalServices { get; set; } }
    }
}
