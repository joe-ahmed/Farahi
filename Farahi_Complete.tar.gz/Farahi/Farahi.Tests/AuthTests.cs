using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Farahi.Tests
{
    /// <summary>
    /// اختبارات الـ Auth API
    /// شغّل: dotnet test
    /// ⚠️ لازم FarahiDB تكون شغالة مع البيانات التجريبية
    /// </summary>
    public class AuthTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;
        private readonly JsonSerializerOptions _json = new() { PropertyNameCaseInsensitive = true };

        public AuthTests(WebApplicationFactory<Program> factory) => _client = factory.CreateClient();

        // ──── ١. تسجيل حساب جديد ────
        [Fact]
        public async Task Register_ValidData_Returns201WithTokens()
        {
            var email = $"test_{Guid.NewGuid():N}@example.com";

            var res = await _client.PostAsJsonAsync("api/auth/register", new
            {
                FirstName = "تست", LastName = "يوزر",
                Email = email, Phone = "01099999999",
                Password = "Test@123", Role = "Customer"
            });

            Assert.Equal(HttpStatusCode.Created, res.StatusCode);

            var body = await Deserialize<Wrapper<AuthData>>(res);
            Assert.True(body.Success);
            Assert.NotEmpty(body.Data!.AccessToken);
            Assert.NotEmpty(body.Data.RefreshToken);
            Assert.Equal("Customer", body.Data.Role);
            Assert.Equal(email, body.Data.Email);
        }

        // ──── ٢. تسجيل بإيميل موجود → 409 ────
        [Fact]
        public async Task Register_DuplicateEmail_Returns409()
        {
            var res = await _client.PostAsJsonAsync("api/auth/register", new
            {
                FirstName = "تكرار", LastName = "إيميل",
                Email = "admin@farahi.com",  // موجود في البيانات التجريبية
                Password = "Test@123", Role = "Customer"
            });

            Assert.Equal(HttpStatusCode.Conflict, res.StatusCode);
        }

        // ──── ٣. تسجيل بباسورد قصير → 400 ────
        [Fact]
        public async Task Register_ShortPassword_Returns400()
        {
            var res = await _client.PostAsJsonAsync("api/auth/register", new
            {
                FirstName = "قصير", LastName = "باس",
                Email = $"short_{Guid.NewGuid():N}@test.com",
                Password = "12", Role = "Customer"
            });

            Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        }

        // ──── ٤. تسجيل بـ Role غلط → 400 ────
        [Fact]
        public async Task Register_InvalidRole_Returns400()
        {
            var res = await _client.PostAsJsonAsync("api/auth/register", new
            {
                FirstName = "أحمد", LastName = "محمد",
                Email = $"role_{Guid.NewGuid():N}@test.com",
                Password = "Test@123", Role = "SuperAdmin"
            });

            Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        }

        // ──── ٥. تسجيل دخول بحساب تجريبي ────
        [Fact]
        public async Task Login_SeedAdmin_ReturnsTokens()
        {
            var res = await _client.PostAsJsonAsync("api/auth/login", new
            {
                Email = "admin@farahi.com",
                Password = "Admin@123"
            });

            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<AuthData>>(res);
            Assert.True(body.Success);
            Assert.Equal("Admin", body.Data!.Role);
            Assert.NotEmpty(body.Data.AccessToken);
        }

        // ──── ٦. تسجيل ثم دخول — الدورة كاملة ────
        [Fact]
        public async Task Register_ThenLogin_Works()
        {
            var email = $"flow_{Guid.NewGuid():N}@test.com";
            var password = "Flow@123";

            await _client.PostAsJsonAsync("api/auth/register", new
            {
                FirstName = "فلو", LastName = "تست",
                Email = email, Password = password, Role = "Provider"
            });

            var loginRes = await _client.PostAsJsonAsync("api/auth/login", new { Email = email, Password = password });

            Assert.Equal(HttpStatusCode.OK, loginRes.StatusCode);
            var body = await Deserialize<Wrapper<AuthData>>(loginRes);
            Assert.Equal("Provider", body.Data!.Role);
        }

        // ──── ٧. دخول بكلمة مرور غلط → 401 ────
        [Fact]
        public async Task Login_WrongPassword_Returns401()
        {
            var res = await _client.PostAsJsonAsync("api/auth/login", new
            {
                Email = "admin@farahi.com",
                Password = "WrongPassword"
            });

            Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
        }

        // ──── ٨. دخول بإيميل مش موجود → 401 ────
        [Fact]
        public async Task Login_NonExistentEmail_Returns401()
        {
            var res = await _client.PostAsJsonAsync("api/auth/login", new
            {
                Email = "nobody@farahi.com",
                Password = "Whatever123"
            });

            Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
        }

        // ──── ٩. البروفايل بدون Token → 401 ────
        [Fact]
        public async Task Profile_NoToken_Returns401()
        {
            var res = await _client.GetAsync("api/auth/profile");
            Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
        }

        // ──── ١٠. البروفايل بـ Token → 200 ────
        [Fact]
        public async Task Profile_WithToken_Returns200()
        {
            var token = await RegisterAndGetToken();

            var req = new HttpRequestMessage(HttpMethod.Get, "api/auth/profile");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var res = await _client.SendAsync(req);

            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── ١١. تحديث Token → 200 ────
        [Fact]
        public async Task Refresh_ValidToken_ReturnsNewTokens()
        {
            var (_, refreshToken) = await RegisterAndGetBothTokens();

            var res = await _client.PostAsJsonAsync("api/auth/refresh", new { RefreshToken = refreshToken });

            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── ١٢. خروج ثم refresh → 401 ────
        [Fact]
        public async Task Logout_ThenRefresh_Returns401()
        {
            var (accessToken, refreshToken) = await RegisterAndGetBothTokens();

            // تسجيل خروج
            var logoutReq = new HttpRequestMessage(HttpMethod.Post, "api/auth/logout");
            logoutReq.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            await _client.SendAsync(logoutReq);

            // محاولة refresh بعد الخروج
            var res = await _client.PostAsJsonAsync("api/auth/refresh", new { RefreshToken = refreshToken });

            Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
        }

        // ──── Helpers ────

        private async Task<string> RegisterAndGetToken()
        {
            var (access, _) = await RegisterAndGetBothTokens();
            return access;
        }

        private async Task<(string access, string refresh)> RegisterAndGetBothTokens()
        {
            var email = $"h_{Guid.NewGuid():N}@test.com";
            var res = await _client.PostAsJsonAsync("api/auth/register", new
            {
                FirstName = "هلبر", LastName = "تست",
                Email = email, Password = "Helper@123", Role = "Customer"
            });
            var body = await Deserialize<Wrapper<AuthData>>(res);
            return (body.Data!.AccessToken, body.Data.RefreshToken);
        }

        private async Task<T> Deserialize<T>(HttpResponseMessage res)
        {
            var json = await res.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<T>(json, _json)!;
        }

        // ──── Response DTOs ────
        private class Wrapper<T> { public bool Success { get; set; } public string Message { get; set; } = ""; public T? Data { get; set; } }
        private class AuthData { public int UserID { get; set; } public string Email { get; set; } = ""; public string Role { get; set; } = ""; public string AccessToken { get; set; } = ""; public string RefreshToken { get; set; } = ""; }
    }
}
