using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Farahi.Tests
{
    public class ServicesTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;
        private readonly JsonSerializerOptions _json = new() { PropertyNameCaseInsensitive = true };

        public ServicesTests(WebApplicationFactory<Program> factory) => _client = factory.CreateClient();

        // ──── Categories ────

        [Fact]
        public async Task Categories_GetAll_ReturnsList()
        {
            var res = await _client.GetAsync("api/categories");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<List<CategoryItem>>>(res);
            Assert.True(body.Data!.Count >= 7); // ٧ فئات في البيانات التجريبية
        }

        [Fact]
        public async Task Categories_GetById_ReturnsOne()
        {
            var res = await _client.GetAsync("api/categories/1");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<CategoryItem>>(res);
            Assert.Equal("Wedding Venues", body.Data!.Name);
        }

        // ──── Amenities ────

        [Fact]
        public async Task Amenities_GetAll_ReturnsList()
        {
            var res = await _client.GetAsync("api/amenities");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<List<AmenityItem>>>(res);
            Assert.True(body.Data!.Count >= 12);
        }

        // ──── Services Browse (لا يحتاج تسجيل دخول) ────

        [Fact]
        public async Task Services_Browse_ReturnsPagedResults()
        {
            var res = await _client.GetAsync("api/services");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<PagedData>>(res);
            Assert.True(body.Data!.TotalCount > 0);
            Assert.True(body.Data.Items.Count > 0);
        }

        [Fact]
        public async Task Services_BrowseByCategory_FiltersCorrectly()
        {
            var res = await _client.GetAsync("api/services?categoryID=1");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<PagedData>>(res);
            Assert.All(body.Data!.Items, item => Assert.Equal(1, item.CategoryID));
        }

        [Fact]
        public async Task Services_BrowseByCity_FiltersCorrectly()
        {
            var res = await _client.GetAsync("api/services?city=Sohag");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<PagedData>>(res);
            Assert.All(body.Data!.Items, item => Assert.Equal("Sohag", item.City));
        }

        // ──── Service Detail ────

        [Fact]
        public async Task Services_GetById_ReturnsDetailWithImagesAndAmenities()
        {
            var res = await _client.GetAsync("api/services/1");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<ServiceDetailData>>(res);
            Assert.Equal("Royal Palace Hall", body.Data!.Name);
            Assert.True(body.Data.Images.Count > 0);
            Assert.True(body.Data.Amenities.Count > 0);
        }

        [Fact]
        public async Task Services_GetById_NonExistent_Returns404()
        {
            var res = await _client.GetAsync("api/services/99999");
            Assert.Equal(HttpStatusCode.NotFound, res.StatusCode);
        }

        // ──── Service Reviews ────

        [Fact]
        public async Task Services_GetReviews_ReturnsList()
        {
            var res = await _client.GetAsync("api/services/4/reviews"); // Glamour Studio عليها تقييم
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);

            var body = await Deserialize<Wrapper<List<ReviewData>>>(res);
            Assert.True(body.Data!.Count > 0);
            Assert.Equal(5, body.Data[0].Rating);
        }

        // ──── Service Availability ────

        [Fact]
        public async Task Services_GetAvailability_ReturnsDates()
        {
            var res = await _client.GetAsync("api/services/1/availability");
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── Provider CRUD (يحتاج تسجيل دخول كـ Provider) ────

        [Fact]
        public async Task Services_Create_AsProvider_Returns201()
        {
            var token = await LoginAndGetToken("ahmed@example.com", "Ahmed@123");

            var req = new HttpRequestMessage(HttpMethod.Post, "api/services");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            req.Content = JsonContent.Create(new
            {
                Name = "Test Service",
                CategoryID = 2,
                City = "Sohag",
                Price = 5000,
                Description = "Test description"
            });
            var res = await _client.SendAsync(req);

            Assert.Equal(HttpStatusCode.Created, res.StatusCode);
        }

        [Fact]
        public async Task Services_Create_AsCustomer_Returns403()
        {
            var token = await LoginAndGetToken("omar@example.com", "Omar@123");

            var req = new HttpRequestMessage(HttpMethod.Post, "api/services");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            req.Content = JsonContent.Create(new
            {
                Name = "Should Fail",
                CategoryID = 1,
                City = "Sohag",
                Price = 1000
            });
            var res = await _client.SendAsync(req);

            Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
        }

        [Fact]
        public async Task Services_GetMy_AsProvider_ReturnsList()
        {
            var token = await LoginAndGetToken("ahmed@example.com", "Ahmed@123");

            var req = new HttpRequestMessage(HttpMethod.Get, "api/services/my");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var res = await _client.SendAsync(req);

            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── Admin Approve ────

        [Fact]
        public async Task Services_Pending_AsAdmin_ReturnsList()
        {
            var token = await LoginAndGetToken("admin@farahi.com", "Admin@123");

            var req = new HttpRequestMessage(HttpMethod.Get, "api/services/pending");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var res = await _client.SendAsync(req);

            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        }

        // ──── Helpers ────

        private async Task<string> LoginAndGetToken(string email, string password)
        {
            var res = await _client.PostAsJsonAsync("api/auth/login", new { Email = email, Password = password });
            var body = await Deserialize<Wrapper<AuthData>>(res);
            return body.Data!.AccessToken;
        }

        private async Task<T> Deserialize<T>(HttpResponseMessage res)
        {
            var json = await res.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<T>(json, _json)!;
        }

        // ──── DTOs ────
        private class Wrapper<T> { public bool Success { get; set; } public T? Data { get; set; } }
        private class AuthData { public string AccessToken { get; set; } = ""; }
        private class CategoryItem { public int CategoryID { get; set; } public string Name { get; set; } = ""; public int ServiceCount { get; set; } }
        private class AmenityItem { public int AmenityID { get; set; } public string Name { get; set; } = ""; }
        private class PagedData { public List<ServiceItem> Items { get; set; } = new(); public int TotalCount { get; set; } }
        private class ServiceItem { public int ServiceID { get; set; } public string Name { get; set; } = ""; public int CategoryID { get; set; } public string City { get; set; } = ""; }
        private class ServiceDetailData { public string Name { get; set; } = ""; public List<object> Images { get; set; } = new(); public List<object> Amenities { get; set; } = new(); }
        private class ReviewData { public int Rating { get; set; } public string? Comment { get; set; } }
    }
}
