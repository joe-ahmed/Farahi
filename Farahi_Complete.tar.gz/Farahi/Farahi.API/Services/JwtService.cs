using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Farahi.API.Helpers;
using Microsoft.IdentityModel.Tokens;

namespace Farahi.API.Services
{
    public class JwtService
    {
        private readonly string _secret;
        private readonly string _issuer;
        private readonly int _accessTokenMinutes;
        private readonly int _refreshTokenDays;

        public JwtService(IConfiguration config)
        {
            _secret = config["Jwt:Secret"] ?? throw new Exception("Jwt:Secret مفقود في appsettings.json");
            _issuer = config["Jwt:Issuer"] ?? "Farahi";
            _accessTokenMinutes = int.Parse(config["Jwt:AccessTokenMinutes"] ?? "60");
            _refreshTokenDays = int.Parse(config["Jwt:RefreshTokenDays"] ?? "7");
        }

        public (string token, DateTime expires) GenerateAccessToken(int userId, string email, string role)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secret));
            var expires = DateTime.UtcNow.AddMinutes(_accessTokenMinutes);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Email, email),
                new Claim(ClaimTypes.Role, role),
            };

            var token = new JwtSecurityToken(
                issuer: _issuer,
                audience: _issuer,
                claims: claims,
                expires: expires,
                signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
            );

            return (new JwtSecurityTokenHandler().WriteToken(token), expires);
        }

        public string GenerateRefreshToken(int userId)
        {
            var randomBytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomBytes);
            var token = Convert.ToBase64String(randomBytes);

            var expiresAt = DateTime.UtcNow.AddDays(_refreshTokenDays);

            // يحفظ في جدول RefreshTokens
            DB.ExecuteNonQuery(
                "INSERT INTO RefreshTokens (UserID, Token, ExpiresAt) VALUES (@UserID, @Token, @ExpiresAt)",
                new[]
                {
                    new SqlParameter("@UserID", userId),
                    new SqlParameter("@Token", token),
                    new SqlParameter("@ExpiresAt", expiresAt)
                });

            return token;
        }

        public int? ValidateRefreshToken(string token)
        {
            var dt = DB.ExecuteQuery(
                @"SELECT TokenID, UserID FROM RefreshTokens 
                  WHERE Token = @Token AND RevokedAt IS NULL AND ExpiresAt > @Now",
                new[]
                {
                    new SqlParameter("@Token", token),
                    new SqlParameter("@Now", DateTime.UtcNow)
                });

            if (dt.Rows.Count == 0) return null;

            var tokenId = Convert.ToInt32(dt.Rows[0]["TokenID"]);
            var userId = Convert.ToInt32(dt.Rows[0]["UserID"]);

            // إلغاء القديم (Token Rotation)
            DB.ExecuteNonQuery(
                "UPDATE RefreshTokens SET RevokedAt = @Now WHERE TokenID = @ID",
                new[]
                {
                    new SqlParameter("@Now", DateTime.UtcNow),
                    new SqlParameter("@ID", tokenId)
                });

            return userId;
        }

        public void RevokeAllUserTokens(int userId)
        {
            DB.ExecuteNonQuery(
                "UPDATE RefreshTokens SET RevokedAt = @Now WHERE UserID = @UserID AND RevokedAt IS NULL",
                new[]
                {
                    new SqlParameter("@Now", DateTime.UtcNow),
                    new SqlParameter("@UserID", userId)
                });
        }
    }
}
