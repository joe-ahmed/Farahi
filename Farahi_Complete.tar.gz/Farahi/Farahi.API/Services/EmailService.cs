using System.Net;
using System.Net.Mail;

namespace Farahi.API.Services
{
    public class EmailService
    {
        private readonly string _from;
        private readonly string _password;
        private readonly string _host;
        private readonly int _port;
        private readonly string _displayName;

        public EmailService(IConfiguration config)
        {
            _from = config["Email:From"] ?? throw new Exception("Email:From مفقود في appsettings.json");
            _password = config["Email:Password"] ?? throw new Exception("Email:Password مفقود في appsettings.json");
            _host = config["Email:Host"] ?? "smtp.gmail.com";
            _port = int.Parse(config["Email:Port"] ?? "587");
            _displayName = config["Email:DisplayName"] ?? "Farahi";
        }

        /// <summary>
        /// بيبعت إيميل — بيشتغل مع Gmail, Outlook, أي SMTP server
        /// </summary>
        public async Task SendAsync(string toEmail, string subject, string htmlBody)
        {
            var msg = new MailMessage
            {
                From = new MailAddress(_from, _displayName),
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true
            };
            msg.To.Add(toEmail);

            using var smtp = new SmtpClient(_host, _port)
            {
                Credentials = new NetworkCredential(_from, _password),
                EnableSsl = true
            };

            await smtp.SendMailAsync(msg);
        }

        /// <summary>
        /// بيبعت كود التحقق من الإيميل للمستخدمين الجدد
        /// </summary>
        public async Task SendVerificationCode(string toEmail, string code, string userName)
        {
            string html = $@"
            <div style='font-family: Tajawal, Arial, sans-serif; direction: rtl; max-width: 480px; margin: 0 auto; padding: 32px; background: #FFFBF0; border-radius: 16px;'>
                <div style='text-align: center; margin-bottom: 24px;'>
                    <div style='font-size: 36px; margin-bottom: 8px;'>🎉</div>
                    <h1 style='font-size: 24px; color: #F5A800; margin: 0;'>فرحي</h1>
                    <p style='color: #888; font-size: 14px;'>Farahi — Wedding Services</p>
                </div>
                <div style='background: white; border-radius: 12px; padding: 24px; text-align: center;'>
                    <h2 style='font-size: 18px; margin-bottom: 8px;'>أهلاً {userName} 👋</h2>
                    <p style='color: #666; font-size: 14px; margin-bottom: 20px;'>كود التحقق الخاص بك هو:</p>
                    <div style='background: #FFF8E7; border: 2px solid #F5A800; border-radius: 12px; padding: 16px; font-size: 32px; font-weight: 900; letter-spacing: 8px; color: #D48C00;'>
                        {code}
                    </div>
                    <p style='color: #999; font-size: 12px; margin-top: 16px;'>الكود صالح لمدة ساعة واحدة</p>
                </div>
                <p style='color: #bbb; font-size: 11px; text-align: center; margin-top: 16px;'>لو مش أنت اللي طلبت الكود، تجاهل الرسالة دي.</p>
            </div>";

            await SendAsync(toEmail, $"فرحي — كود التحقق: {code}", html);
        }

        /// <summary>
        /// بيبعت كود التحقق من الخدمة الجديدة لمقدم الخدمة
        /// </summary>
        public async Task SendServiceVerificationCode(string toEmail, string code, string serviceName)
        {
            string html = $@"
            <div style='font-family: Tajawal, Arial, sans-serif; direction: rtl; max-width: 480px; margin: 0 auto; padding: 32px; background: #FFFBF0; border-radius: 16px;'>
                <div style='text-align: center; margin-bottom: 24px;'>
                    <div style='font-size: 36px; margin-bottom: 8px;'>🏛️</div>
                    <h1 style='font-size: 24px; color: #F5A800; margin: 0;'>فرحي</h1>
                </div>
                <div style='background: white; border-radius: 12px; padding: 24px; text-align: center;'>
                    <h2 style='font-size: 18px; margin-bottom: 8px;'>تفعيل خدمة: {serviceName}</h2>
                    <p style='color: #666; font-size: 14px; margin-bottom: 20px;'>أدخل الكود التالي في لوحة التحكم لتفعيل خدمتك:</p>
                    <div style='background: #FFF8E7; border: 2px solid #F5A800; border-radius: 12px; padding: 16px; font-size: 32px; font-weight: 900; letter-spacing: 8px; color: #D48C00;'>
                        {code}
                    </div>
                    <p style='color: #999; font-size: 12px; margin-top: 16px;'>الكود صالح لمدة ٢٤ ساعة</p>
                </div>
            </div>";

            await SendAsync(toEmail, $"فرحي — تفعيل خدمة: {serviceName} (كود: {code})", html);
        }
    }
}
