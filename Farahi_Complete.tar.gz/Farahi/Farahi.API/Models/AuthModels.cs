using System.ComponentModel.DataAnnotations;

namespace Farahi.API.Models
{
    // ─── Requests ───

    public class RegisterRequest
    {
        [Required(ErrorMessage = "الاسم الأول مطلوب")]
        [MaxLength(100)]
        public string FirstName { get; set; } = "";

        [Required(ErrorMessage = "الاسم الأخير مطلوب")]
        [MaxLength(100)]
        public string LastName { get; set; } = "";

        [Required(ErrorMessage = "البريد الإلكتروني مطلوب")]
        [EmailAddress(ErrorMessage = "البريد الإلكتروني غير صالح")]
        [MaxLength(256)]
        public string Email { get; set; } = "";

        [MaxLength(20)]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "كلمة المرور مطلوبة")]
        [MinLength(6, ErrorMessage = "كلمة المرور لازم تكون ٦ حروف على الأقل")]
        public string Password { get; set; } = "";

        [Required(ErrorMessage = "نوع الحساب مطلوب")]
        [RegularExpression("^(Customer|Provider)$", ErrorMessage = "نوع الحساب لازم يكون Customer أو Provider")]
        public string Role { get; set; } = "Customer";
    }

    public class LoginRequest
    {
        [Required(ErrorMessage = "البريد الإلكتروني مطلوب")]
        [EmailAddress]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "كلمة المرور مطلوبة")]
        public string Password { get; set; } = "";
    }

    public class RefreshTokenRequest
    {
        [Required]
        public string RefreshToken { get; set; } = "";
    }

    // ─── Responses ───

    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = "";
        public T? Data { get; set; }

        public static ApiResponse<T> Ok(T data, string message = "تمت العملية بنجاح") =>
            new() { Success = true, Message = message, Data = data };

        public static ApiResponse<T> Fail(string message) =>
            new() { Success = false, Message = message };
    }

    public class AuthResponse
    {
        public int UserID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Email { get; set; } = "";
        public string? Phone { get; set; }
        public string Role { get; set; } = "";
        public string? ProfileImageUrl { get; set; }
        public string AccessToken { get; set; } = "";
        public string RefreshToken { get; set; } = "";
        public DateTime AccessTokenExpires { get; set; }
    }

    public class UserProfile
    {
        public int UserID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Email { get; set; } = "";
        public string? Phone { get; set; }
        public string Role { get; set; } = "";
        public string? ProfileImageUrl { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
