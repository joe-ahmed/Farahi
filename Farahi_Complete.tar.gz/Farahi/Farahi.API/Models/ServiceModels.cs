using System.ComponentModel.DataAnnotations;

namespace Farahi.API.Models
{
    public class CreateServiceRequest
    {
        [Required] [MaxLength(200)] public string Name { get; set; } = "";
        [MaxLength(200)] public string? NameAr { get; set; }
        [MaxLength(4000)] public string? Description { get; set; }
        [MaxLength(4000)] public string? DescriptionAr { get; set; }
        [Required] public int CategoryID { get; set; }
        [Required] [MaxLength(100)] public string City { get; set; } = "";
        [MaxLength(500)] public string? Address { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        [Required] [Range(0, double.MaxValue)] public decimal Price { get; set; }
        [Range(1, int.MaxValue)] public int? Capacity { get; set; }
        [MaxLength(20)] public string? Phone { get; set; }
        public List<int>? AmenityIDs { get; set; }
        public List<string>? ImageUrls { get; set; }
    }

    public class UpdateServiceRequest
    {
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? Description { get; set; }
        public string? DescriptionAr { get; set; }
        public string? City { get; set; }
        public string? Address { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public decimal? Price { get; set; }
        public int? Capacity { get; set; }
        public List<int>? AmenityIDs { get; set; }
    }

    public class VerifyCodeRequest
    {
        [Required] public string Code { get; set; } = "";
    }

    public class ServiceFilterRequest
    {
        public int? CategoryID { get; set; }
        public string? City { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public int? MinCapacity { get; set; }
        public int? MinRating { get; set; }
        public string? SortBy { get; set; } = "rating";
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 12;
    }

    public class ServiceListItem
    {
        public int ServiceID { get; set; }
        public string Name { get; set; } = "";
        public string? NameAr { get; set; }
        public string City { get; set; } = "";
        public decimal Price { get; set; }
        public int? Capacity { get; set; }
        public decimal AverageRating { get; set; }
        public int ReviewCount { get; set; }
        public int CategoryID { get; set; }
        public string CategoryName { get; set; } = "";
        public string? CategoryNameAr { get; set; }
        public string ProviderName { get; set; } = "";
        public string? CoverImageUrl { get; set; }
    }

    public class ServiceDetail
    {
        public int ServiceID { get; set; }
        public int ProviderID { get; set; }
        public string ProviderName { get; set; } = "";
        public string? ProviderPhone { get; set; }
        public string? ServicePhone { get; set; }
        public int CategoryID { get; set; }
        public string CategoryName { get; set; } = "";
        public string? CategoryNameAr { get; set; }
        public string Name { get; set; } = "";
        public string? NameAr { get; set; }
        public string? Description { get; set; }
        public string? DescriptionAr { get; set; }
        public string City { get; set; } = "";
        public string? Address { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public decimal Price { get; set; }
        public int? Capacity { get; set; }
        public decimal AverageRating { get; set; }
        public int ReviewCount { get; set; }
        public bool IsApproved { get; set; }
        public DateTime CreatedAt { get; set; }
        public List<ServiceImageItem> Images { get; set; } = new();
        public List<AmenityItem> Amenities { get; set; } = new();
    }

    public class ServiceImageItem { public int ImageID { get; set; } public string ImageUrl { get; set; } = ""; public int DisplayOrder { get; set; } public string? AltText { get; set; } }
    public class AmenityItem { public int AmenityID { get; set; } public string Name { get; set; } = ""; public string? NameAr { get; set; } }
    public class PagedResult<T> { public List<T> Items { get; set; } = new(); public int TotalCount { get; set; } public int Page { get; set; } public int PageSize { get; set; } public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize); }
}
