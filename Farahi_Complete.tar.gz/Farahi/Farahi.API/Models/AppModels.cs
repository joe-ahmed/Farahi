using System.ComponentModel.DataAnnotations;

namespace Farahi.API.Models
{
    // ═══ Bookings ═══
    public class CreateBookingRequest
    {
        [Required] public int ServiceID { get; set; }
        [Required] public DateTime EventDate { get; set; }
        [MaxLength(2000)] public string? Notes { get; set; }
        [Required] [RegularExpression("^(Cash|VodafoneCash|Card)$")] public string PaymentMethod { get; set; } = "Cash";
        public string? WalletPhone { get; set; }  // مطلوب لفودافون كاش
    }
    public class CancelBookingRequest { [MaxLength(500)] public string? Reason { get; set; } }
    public class BookingResponse
    {
        public int BookingID { get; set; } public int UserID { get; set; } public string CustomerName { get; set; } = ""; public string? CustomerPhone { get; set; }
        public int ServiceID { get; set; } public string ServiceName { get; set; } = ""; public string? ServiceNameAr { get; set; } public string ServiceCity { get; set; } = "";
        public string ProviderName { get; set; } = ""; public string CategoryName { get; set; } = "";
        public DateTime EventDate { get; set; } public DateTime BookingDate { get; set; } public string Status { get; set; } = ""; public decimal TotalPrice { get; set; }
        public string? Notes { get; set; } public string? CancelReason { get; set; }
        public DateTime? ConfirmedAt { get; set; } public DateTime? CompletedAt { get; set; } public DateTime? CancelledAt { get; set; } public bool HasReview { get; set; }
    }

    // ═══ Reviews ═══
    public class CreateReviewRequest
    {
        [Required] public int BookingID { get; set; }
        [Required] [Range(1, 5)] public int Rating { get; set; }
        [MaxLength(2000)] public string? Comment { get; set; }
    }
    public class ReviewResponse
    {
        public int ReviewID { get; set; } public int UserID { get; set; } public string CustomerName { get; set; } = ""; public string? ProfileImageUrl { get; set; }
        public int Rating { get; set; } public string? Comment { get; set; } public DateTime CreatedAt { get; set; }
    }

    // ═══ Notifications ═══
    public class NotificationResponse { public int NotificationID { get; set; } public string Title { get; set; } = ""; public string Message { get; set; } = ""; public string Type { get; set; } = ""; public int? ReferenceID { get; set; } public bool IsRead { get; set; } public DateTime CreatedAt { get; set; } }

    // ═══ Bug Reports ═══
    public class CreateBugReportRequest { [Required] [MaxLength(200)] public string Title { get; set; } = ""; [Required] [MaxLength(4000)] public string Description { get; set; } = ""; }
    public class UpdateBugStatusRequest { [Required] [RegularExpression("^(Open|InProgress|Resolved|Closed)$")] public string Status { get; set; } = ""; }
    public class BugReportResponse { public int ReportID { get; set; } public int UserID { get; set; } public string UserName { get; set; } = ""; public string Title { get; set; } = ""; public string Description { get; set; } = ""; public string Status { get; set; } = ""; public DateTime CreatedAt { get; set; } public DateTime? ResolvedAt { get; set; } }

    // ═══ Favorites ═══
    public class FavoriteResponse { public int ServiceID { get; set; } public string Name { get; set; } = ""; public string? NameAr { get; set; } public string City { get; set; } = ""; public decimal Price { get; set; } public decimal AverageRating { get; set; } public string? CoverImageUrl { get; set; } public DateTime AddedAt { get; set; } }

    // ═══ Categories ═══
    public class CategoryResponse { public int CategoryID { get; set; } public string Name { get; set; } = ""; public string? NameAr { get; set; } public string? Description { get; set; } public string? DescriptionAr { get; set; } public string? IconUrl { get; set; } public int ServiceCount { get; set; } }

    // ═══ Dashboard ═══
    public class ProviderDashboard { public int TotalServices { get; set; } public int TotalBookings { get; set; } public decimal TotalEarnings { get; set; } public int PendingBookings { get; set; } public int UpcomingBookings { get; set; } public decimal AverageRating { get; set; } public int TotalReviews { get; set; } public List<BookingResponse> RecentBookings { get; set; } = new(); }
    public class AdminDashboard { public int TotalUsers { get; set; } public int TotalProviders { get; set; } public int TotalCustomers { get; set; } public int TotalServices { get; set; } public int PendingApprovals { get; set; } public int TotalBookings { get; set; } public decimal TotalRevenue { get; set; } public int OpenBugReports { get; set; } }

    // ═══ Availability ═══
    public class SetAvailabilityRequest { [Required] public DateTime Date { get; set; } [Required] public bool IsAvailable { get; set; } public string? Notes { get; set; } }
    public class AvailabilityResponse { public DateTime Date { get; set; } public bool IsAvailable { get; set; } public string? Notes { get; set; } }

    // ═══ Auth additions ═══
    public class VerifyEmailRequest { [Required] public string Code { get; set; } = ""; }

    // ═══ Admin ═══
    public class BlockUserRequest { [Required] public int UserID { get; set; } }
}

// ═══ Payments ═══
namespace Farahi.API.Models
{
    public class PaymentInfo
    {
        [System.ComponentModel.DataAnnotations.Required]
        [System.ComponentModel.DataAnnotations.RegularExpression("^(Cash|VodafoneCash|Card)$")]
        public string Method { get; set; } = "Cash";
        public string? WalletPhone { get; set; }  // لفودافون كاش
    }

    public class ConfirmPaymentRequest
    {
        [System.ComponentModel.DataAnnotations.Required]
        public string TransactionRef { get; set; } = "";
    }

    public class PaymentResponse
    {
        public int PaymentID { get; set; }
        public int BookingID { get; set; }
        public decimal Amount { get; set; }
        public string Method { get; set; } = "";
        public string MethodAr { get; set; } = "";
        public string Status { get; set; } = "";
        public string StatusAr { get; set; } = "";
        public string? TransactionRef { get; set; }
        public string? WalletPhone { get; set; }
        public DateTime? PaidAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
