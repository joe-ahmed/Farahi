using System.Data.SqlClient; using System.Security.Claims;
using Farahi.API.Helpers; using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController] [Route("api/[controller]")]
    public class ReviewsController : ControllerBase
    {
        [Authorize(Roles="Customer")] [HttpPost]
        public IActionResult Create([FromBody] CreateReviewRequest req)
        {
            if(!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("Invalid"));
            int uid=int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var bk=DB.ExecuteQuery("SELECT ServiceID,Status FROM Bookings WHERE BookingID=@B AND UserID=@U",new[]{new SqlParameter("@B",req.BookingID),new SqlParameter("@U",uid)});
            if(bk.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Booking not found"));
            if(bk.Rows[0]["Status"].ToString()!="Completed") return BadRequest(ApiResponse<object>.Fail("Booking must be completed to review"));
            int sid=(int)bk.Rows[0]["ServiceID"];
            var dup=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Reviews WHERE BookingID=@B",new[]{new SqlParameter("@B",req.BookingID)}));
            if(dup>0) return Conflict(ApiResponse<object>.Fail("Already reviewed"));

            var rid=Convert.ToInt32(DB.ExecuteScalar(@"INSERT INTO Reviews(UserID,ServiceID,BookingID,Rating,Comment) OUTPUT INSERTED.ReviewID VALUES(@U,@S,@B,@R,@C)",
                new[]{new SqlParameter("@U",uid),new SqlParameter("@S",sid),new SqlParameter("@B",req.BookingID),new SqlParameter("@R",req.Rating),new SqlParameter("@C",(object?)req.Comment??DBNull.Value)}));

            DB.ExecuteNonQuery(@"UPDATE Services SET AverageRating=(SELECT AVG(CAST(Rating AS DECIMAL(3,2))) FROM Reviews WHERE ServiceID=@S),
                ReviewCount=(SELECT COUNT(*) FROM Reviews WHERE ServiceID=@S),UpdatedAt=GETDATE() WHERE ServiceID=@S",new[]{new SqlParameter("@S",sid)});

            var prov=DB.ExecuteQuery("SELECT ProviderID,Name FROM Services WHERE ServiceID=@S",new[]{new SqlParameter("@S",sid)});
            if(prov.Rows.Count>0) DB.ExecuteNonQuery("INSERT INTO Notifications(UserID,Title,Message,Type,ReferenceID) VALUES(@U,@T,@M,@Ty,@R)",
                new[]{new SqlParameter("@U",(int)prov.Rows[0]["ProviderID"]),new SqlParameter("@T","New Review"),new SqlParameter("@M",$"New {req.Rating}-star review for {prov.Rows[0]["Name"]}"),new SqlParameter("@Ty","ReviewReceived"),new SqlParameter("@R",rid)});

            return Created("",ApiResponse<object>.Ok(new{ReviewID=rid},"Review submitted"));
        }

        // DELETE api/reviews/{id} — حذف تقييم (المستخدم صاحب التقييم أو المدير)
        [Authorize] [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            int uid=int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value); string role=User.FindFirst(ClaimTypes.Role)!.Value;
            var dt=DB.ExecuteQuery("SELECT UserID,ServiceID FROM Reviews WHERE ReviewID=@ID",new[]{new SqlParameter("@ID",id)});
            if(dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            if(role!="Admin"&&(int)dt.Rows[0]["UserID"]!=uid) return Forbid();
            int sid=(int)dt.Rows[0]["ServiceID"];
            DB.ExecuteNonQuery("DELETE FROM Reviews WHERE ReviewID=@ID",new[]{new SqlParameter("@ID",id)});
            DB.ExecuteNonQuery(@"UPDATE Services SET AverageRating=ISNULL((SELECT AVG(CAST(Rating AS DECIMAL(3,2))) FROM Reviews WHERE ServiceID=@S),0),
                ReviewCount=(SELECT COUNT(*) FROM Reviews WHERE ServiceID=@S),UpdatedAt=GETDATE() WHERE ServiceID=@S",new[]{new SqlParameter("@S",sid)});
            return Ok(ApiResponse<object>.Ok(null,"Review deleted"));
        }
    }
}
