using System.Data;
using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AmenitiesController : ControllerBase
    {
        // ──────────────────────────────────────────────
        // GET api/amenities — كل المميزات (للفلاتر)
        // ──────────────────────────────────────────────
        [HttpGet]
        public IActionResult GetAll()
        {
            var dt = DB.ExecuteQuery("SELECT AmenityID, Name, NameAr, IconUrl FROM Amenities ORDER BY Name");

            var list = new List<AmenityItem>();
            foreach (DataRow row in dt.Rows)
                list.Add(new AmenityItem
                {
                    AmenityID = Convert.ToInt32(row["AmenityID"]),
                    Name = row["Name"].ToString()!,
                    NameAr = row["NameAr"] == DBNull.Value ? null : row["NameAr"].ToString()
                });

            return Ok(ApiResponse<List<AmenityItem>>.Ok(list));
        }
    }
}
