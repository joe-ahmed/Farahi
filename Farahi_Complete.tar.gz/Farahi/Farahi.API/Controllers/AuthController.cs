using System.Data.SqlClient; using System.Security.Claims;
using Farahi.API.Helpers; using Farahi.API.Models; using Farahi.API.Services;
using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController] [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly JwtService _jwt;
        private readonly EmailService _email;
        public AuthController(JwtService jwt, EmailService email) { _jwt = jwt; _email = email; }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest req)
        {
            if(!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("Invalid data"));
            var count=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Users WHERE Email=@E",new[]{new SqlParameter("@E",req.Email)}));
            if(count>0) return Conflict(ApiResponse<object>.Fail("Email already registered"));

            string hash=BCrypt.Net.BCrypt.HashPassword(req.Password);
            string code=new Random().Next(100000,999999).ToString();

            DB.ExecuteNonQuery(@"INSERT INTO Users(FirstName,LastName,Email,Phone,PasswordHash,Role,VerificationCode,VerificationCodeExpiry)
                VALUES(@F,@L,@E,@P,@H,@R,@C,DATEADD(HOUR,1,GETDATE()))",
                new[]{new SqlParameter("@F",req.FirstName),new SqlParameter("@L",req.LastName),new SqlParameter("@E",req.Email),
                new SqlParameter("@P",(object?)req.Phone??DBNull.Value),new SqlParameter("@H",hash),new SqlParameter("@R",req.Role),new SqlParameter("@C",code)});

            var dt=DB.ExecuteQuery("SELECT UserID,FirstName,LastName,Email,Phone,Role,ProfileImageUrl FROM Users WHERE Email=@E",new[]{new SqlParameter("@E",req.Email)});
            var row=dt.Rows[0]; int uid=(int)row["UserID"];
            var(at,exp)=_jwt.GenerateAccessToken(uid,req.Email,req.Role); var rt=_jwt.GenerateRefreshToken(uid);

            // إرسال كود التحقق بالإيميل
            try { await _email.SendVerificationCode(req.Email, code, req.FirstName); }
            catch (Exception ex) { Console.WriteLine($"⚠️ Email failed: {ex.Message}"); }

            return Created("",ApiResponse<AuthResponse>.Ok(new(){UserID=uid,FirstName=row["FirstName"].ToString()!,LastName=row["LastName"].ToString()!,
                Email=row["Email"].ToString()!,Phone=row["Phone"]==DBNull.Value?null:row["Phone"].ToString(),Role=row["Role"].ToString()!,
                ProfileImageUrl=row["ProfileImageUrl"]==DBNull.Value?null:row["ProfileImageUrl"].ToString(),
                AccessToken=at,RefreshToken=rt,AccessTokenExpires=exp},"Account created. Check your email for the verification code."));
        }

        [HttpPost("verify-email")]
        public IActionResult VerifyEmail([FromBody] VerifyEmailRequest req)
        {
            var dt=DB.ExecuteQuery("SELECT UserID FROM Users WHERE VerificationCode=@C AND VerificationCodeExpiry>GETDATE()",new[]{new SqlParameter("@C",req.Code)});
            if(dt.Rows.Count==0) return BadRequest(ApiResponse<object>.Fail("Invalid or expired code"));
            DB.ExecuteNonQuery("UPDATE Users SET IsEmailVerified=1,VerificationCode=NULL WHERE UserID=@ID",new[]{new SqlParameter("@ID",(int)dt.Rows[0]["UserID"])});
            return Ok(ApiResponse<object>.Ok(null,"Email verified!"));
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest req)
        {
            if(!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("Invalid data"));
            var dt=DB.ExecuteQuery(@"SELECT UserID,FirstName,LastName,Email,Phone,PasswordHash,Role,ProfileImageUrl
                FROM Users WHERE Email=@E AND IsActive=1",new[]{new SqlParameter("@E",req.Email)});
            if(dt.Rows.Count==0) return Unauthorized(ApiResponse<object>.Fail("Invalid email or password"));
            var row=dt.Rows[0];
            if(!BCrypt.Net.BCrypt.Verify(req.Password,row["PasswordHash"].ToString()!)) return Unauthorized(ApiResponse<object>.Fail("Invalid email or password"));
            int uid=(int)row["UserID"]; string email=row["Email"].ToString()!; string role=row["Role"].ToString()!;
            var(at,exp)=_jwt.GenerateAccessToken(uid,email,role); var rt=_jwt.GenerateRefreshToken(uid);
            return Ok(ApiResponse<AuthResponse>.Ok(new(){UserID=uid,FirstName=row["FirstName"].ToString()!,LastName=row["LastName"].ToString()!,
                Email=email,Phone=row["Phone"]==DBNull.Value?null:row["Phone"].ToString(),Role=role,
                ProfileImageUrl=row["ProfileImageUrl"]==DBNull.Value?null:row["ProfileImageUrl"].ToString(),
                AccessToken=at,RefreshToken=rt,AccessTokenExpires=exp},"Login successful"));
        }

        [HttpPost("refresh")]
        public IActionResult RefreshToken([FromBody] RefreshTokenRequest req)
        {
            var uid=_jwt.ValidateRefreshToken(req.RefreshToken);
            if(uid==null) return Unauthorized(ApiResponse<object>.Fail("Invalid refresh token"));
            var dt=DB.ExecuteQuery("SELECT Email,Role FROM Users WHERE UserID=@ID AND IsActive=1",new[]{new SqlParameter("@ID",uid.Value)});
            if(dt.Rows.Count==0) return Unauthorized(ApiResponse<object>.Fail("User not found"));
            var(at,exp)=_jwt.GenerateAccessToken(uid.Value,dt.Rows[0]["Email"].ToString()!,dt.Rows[0]["Role"].ToString()!);
            var nrt=_jwt.GenerateRefreshToken(uid.Value);
            return Ok(ApiResponse<object>.Ok(new{AccessToken=at,RefreshToken=nrt,AccessTokenExpires=exp},"Token refreshed"));
        }

        [Authorize] [HttpPost("logout")]
        public IActionResult Logout() { _jwt.RevokeAllUserTokens(int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value)); return Ok(ApiResponse<object>.Ok((object?)null,"Logged out")); }

        [Authorize] [HttpGet("profile")]
        public IActionResult GetProfile()
        {
            int uid=int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var dt=DB.ExecuteQuery("SELECT UserID,FirstName,LastName,Email,Phone,Role,ProfileImageUrl,IsEmailVerified,CreatedAt FROM Users WHERE UserID=@ID AND IsActive=1",new[]{new SqlParameter("@ID",uid)});
            if(dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("User not found"));
            var r=dt.Rows[0];
            return Ok(ApiResponse<UserProfile>.Ok(new(){UserID=(int)r["UserID"],FirstName=r["FirstName"].ToString()!,LastName=r["LastName"].ToString()!,
                Email=r["Email"].ToString()!,Phone=r["Phone"]==DBNull.Value?null:r["Phone"].ToString(),Role=r["Role"].ToString()!,
                ProfileImageUrl=r["ProfileImageUrl"]==DBNull.Value?null:r["ProfileImageUrl"].ToString(),CreatedAt=(DateTime)r["CreatedAt"]}));
        }
    }
}
