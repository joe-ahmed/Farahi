using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;
using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class NotificationsController : ControllerBase
    {
        // ──────────────────────────────────────────────
        // GET api/notifications — إشعاراتي
        // ──────────────────────────────────────────────
        [HttpGet]
        public IActionResult GetMine([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            int userId = GetUserId();
            int offset = (page - 1) * pageSize;

            var dt = DB.ExecuteQuery(
                @"SELECT NotificationID, Title, Message, Type, ReferenceID, IsRead, CreatedAt
                  FROM Notifications WHERE UserID = @UID
                  ORDER BY CreatedAt DESC
                  OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY",
                new[] { new SqlParameter("@UID", userId), new SqlParameter("@Offset", offset), new SqlParameter("@PageSize", pageSize) });

            var list = new List<NotificationResponse>();
            foreach (DataRow row in dt.Rows)
                list.Add(new NotificationResponse
                {
                    NotificationID = Convert.ToInt32(row["NotificationID"]),
                    Title = row["Title"].ToString()!,
                    Message = row["Message"].ToString()!,
                    Type = row["Type"].ToString()!,
                    ReferenceID = row["ReferenceID"] == DBNull.Value ? null : Convert.ToInt32(row["ReferenceID"]),
                    IsRead = Convert.ToBoolean(row["IsRead"]),
                    CreatedAt = Convert.ToDateTime(row["CreatedAt"])
                });

            return Ok(ApiResponse<List<NotificationResponse>>.Ok(list));
        }

        // ──────────────────────────────────────────────
        // GET api/notifications/unread-count — عدد غير المقروءة (للـ badge)
        // ──────────────────────────────────────────────
        [HttpGet("unread-count")]
        public IActionResult UnreadCount()
        {
            int userId = GetUserId();
            var count = Convert.ToInt32(DB.ExecuteScalar(
                "SELECT COUNT(*) FROM Notifications WHERE UserID = @UID AND IsRead = 0",
                new[] { new SqlParameter("@UID", userId) }));

            return Ok(ApiResponse<object>.Ok(new { Count = count }));
        }

        // ──────────────────────────────────────────────
        // PUT api/notifications/{id}/read — قراءة إشعار
        // ──────────────────────────────────────────────
        [HttpPut("{id}/read")]
        public IActionResult MarkAsRead(int id)
        {
            int userId = GetUserId();
            int affected = DB.ExecuteNonQuery(
                "UPDATE Notifications SET IsRead = 1 WHERE NotificationID = @ID AND UserID = @UID",
                new[] { new SqlParameter("@ID", id), new SqlParameter("@UID", userId) });

            if (affected == 0) return NotFound(ApiResponse<object>.Fail("الإشعار غير موجود"));
            return Ok(ApiResponse<object>.Ok(null, "تم"));
        }

        // ──────────────────────────────────────────────
        // PUT api/notifications/read-all — قراءة الكل
        // ──────────────────────────────────────────────
        [HttpPut("read-all")]
        public IActionResult MarkAllAsRead()
        {
            int userId = GetUserId();
            DB.ExecuteNonQuery(
                "UPDATE Notifications SET IsRead = 1 WHERE UserID = @UID AND IsRead = 0",
                new[] { new SqlParameter("@UID", userId) });

            return Ok(ApiResponse<object>.Ok(null, "تم قراءة كل الإشعارات"));
        }

        private int GetUserId() => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
