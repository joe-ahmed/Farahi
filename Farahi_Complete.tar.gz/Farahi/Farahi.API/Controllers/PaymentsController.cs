using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;
using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PaymentsController : ControllerBase
    {
        // ──────────────────────────────────────────────
        // GET api/payments/{bookingId} — حالة الدفع لحجز معين
        // ──────────────────────────────────────────────
        [HttpGet("{bookingId}")]
        public IActionResult GetByBooking(int bookingId)
        {
            int uid = Uid();
            // التحقق: صاحب الحجز أو مقدم الخدمة
            var auth = DB.ExecuteQuery(
                @"SELECT b.UserID, s.ProviderID FROM Bookings b
                  INNER JOIN Services s ON b.ServiceID = s.ServiceID
                  WHERE b.BookingID = @BID", new[] { new SqlParameter("@BID", bookingId) });

            if (auth.Rows.Count == 0) return NotFound(ApiResponse<object>.Fail("Booking not found"));
            if ((int)auth.Rows[0]["UserID"] != uid && (int)auth.Rows[0]["ProviderID"] != uid)
                return Forbid();

            var dt = DB.ExecuteQuery(
                "SELECT * FROM Payments WHERE BookingID = @BID",
                new[] { new SqlParameter("@BID", bookingId) });

            if (dt.Rows.Count == 0)
                return NotFound(ApiResponse<object>.Fail("No payment found for this booking"));

            return Ok(ApiResponse<PaymentResponse>.Ok(MapPayment(dt.Rows[0])));
        }

        // ──────────────────────────────────────────────
        // POST api/payments/{bookingId}/confirm — تأكيد الدفع
        // ──────────────────────────────────────────────
        // للدفع النقدي: المقدم يأكد إنه استلم الفلوس
        // لفودافون كاش: العميل يدخل رقم العملية
        // ──────────────────────────────────────────────
        [HttpPost("{bookingId}/confirm")]
        public IActionResult Confirm(int bookingId, [FromBody] ConfirmPaymentRequest req)
        {
            var dt = DB.ExecuteQuery(
                @"SELECT p.PaymentID, p.Method, p.Status, b.UserID, s.ProviderID
                  FROM Payments p
                  INNER JOIN Bookings b ON p.BookingID = b.BookingID
                  INNER JOIN Services s ON b.ServiceID = s.ServiceID
                  WHERE p.BookingID = @BID",
                new[] { new SqlParameter("@BID", bookingId) });

            if (dt.Rows.Count == 0) return NotFound(ApiResponse<object>.Fail("Payment not found"));
            var row = dt.Rows[0];
            if (row["Status"].ToString() == "Paid") return BadRequest(ApiResponse<object>.Fail("Already paid"));

            int uid = Uid();
            string method = row["Method"].ToString()!;

            // الدفع النقدي: المقدم بس يقدر يأكد
            if (method == "Cash" && (int)row["ProviderID"] != uid)
                return BadRequest(ApiResponse<object>.Fail("Only the provider can confirm cash payments"));

            // فودافون كاش: العميل أو المقدم يأكد
            if (method == "VodafoneCash" && (int)row["UserID"] != uid && (int)row["ProviderID"] != uid)
                return Forbid();

            DB.ExecuteNonQuery(
                "UPDATE Payments SET Status = 'Paid', TransactionRef = @Ref, PaidAt = GETDATE(), UpdatedAt = GETDATE() WHERE PaymentID = @PID",
                new[] { new SqlParameter("@Ref", req.TransactionRef), new SqlParameter("@PID", (int)row["PaymentID"]) });

            // إشعار الطرف الآخر
            int notifyUser = uid == (int)row["UserID"] ? (int)row["ProviderID"] : (int)row["UserID"];
            DB.ExecuteNonQuery(
                "INSERT INTO Notifications (UserID, Title, Message, Type, ReferenceID) VALUES (@U, @T, @M, 'BookingConfirmed', @R)",
                new[] {
                    new SqlParameter("@U", notifyUser),
                    new SqlParameter("@T", "Payment Confirmed"),
                    new SqlParameter("@M", $"Payment confirmed for booking #{bookingId}"),
                    new SqlParameter("@R", bookingId)
                });

            return Ok(ApiResponse<object>.Ok(null, "Payment confirmed"));
        }

        // ──────────────────────────────────────────────
        // POST api/payments/{bookingId}/refund — استرداد (مقدم الخدمة فقط)
        // ──────────────────────────────────────────────
        [HttpPost("{bookingId}/refund")]
        public IActionResult Refund(int bookingId)
        {
            int uid = Uid();

            var dt = DB.ExecuteQuery(
                @"SELECT p.PaymentID, p.Status, s.ProviderID, b.UserID
                  FROM Payments p
                  INNER JOIN Bookings b ON p.BookingID = b.BookingID
                  INNER JOIN Services s ON b.ServiceID = s.ServiceID
                  WHERE p.BookingID = @BID",
                new[] { new SqlParameter("@BID", bookingId) });

            if (dt.Rows.Count == 0) return NotFound(ApiResponse<object>.Fail("Payment not found"));
            var row = dt.Rows[0];

            if ((int)row["ProviderID"] != uid) return Forbid();
            if (row["Status"].ToString() != "Paid") return BadRequest(ApiResponse<object>.Fail("Can only refund paid payments"));

            DB.ExecuteNonQuery(
                "UPDATE Payments SET Status = 'Refunded', UpdatedAt = GETDATE() WHERE PaymentID = @PID",
                new[] { new SqlParameter("@PID", (int)row["PaymentID"]) });

            DB.ExecuteNonQuery(
                "INSERT INTO Notifications (UserID, Title, Message, Type, ReferenceID) VALUES (@U, @T, @M, 'General', @R)",
                new[] {
                    new SqlParameter("@U", (int)row["UserID"]),
                    new SqlParameter("@T", "Payment Refunded"),
                    new SqlParameter("@M", $"Your payment for booking #{bookingId} has been refunded"),
                    new SqlParameter("@R", bookingId)
                });

            return Ok(ApiResponse<object>.Ok(null, "Payment refunded"));
        }

        // ──────────────────────────────────────────────
        // GET api/payments/provider — كل مدفوعات خدماتي (للمقدم)
        // ──────────────────────────────────────────────
        [Authorize(Roles = "Provider")]
        [HttpGet("provider")]
        public IActionResult ProviderPayments()
        {
            var dt = DB.ExecuteQuery(
                @"SELECT p.* FROM Payments p
                  INNER JOIN Bookings b ON p.BookingID = b.BookingID
                  INNER JOIN Services s ON b.ServiceID = s.ServiceID
                  WHERE s.ProviderID = @PID ORDER BY p.CreatedAt DESC",
                new[] { new SqlParameter("@PID", Uid()) });

            var list = new List<PaymentResponse>();
            foreach (DataRow row in dt.Rows) list.Add(MapPayment(row));
            return Ok(ApiResponse<List<PaymentResponse>>.Ok(list));
        }

        // ──── Helpers ────

        private int Uid() => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        private PaymentResponse MapPayment(DataRow r)
        {
            string method = r["Method"].ToString()!;
            string status = r["Status"].ToString()!;
            return new()
            {
                PaymentID = (int)r["PaymentID"],
                BookingID = (int)r["BookingID"],
                Amount = (decimal)r["Amount"],
                Method = method,
                MethodAr = method switch { "Cash" => "نقدي", "VodafoneCash" => "فودافون كاش", "Card" => "كارت", _ => method },
                Status = status,
                StatusAr = status switch { "Pending" => "قيد الانتظار", "Paid" => "مدفوع", "Failed" => "فشل", "Refunded" => "مسترد", _ => status },
                TransactionRef = r["TransactionRef"] == DBNull.Value ? null : r["TransactionRef"].ToString(),
                WalletPhone = r["WalletPhone"] == DBNull.Value ? null : r["WalletPhone"].ToString(),
                PaidAt = r["PaidAt"] == DBNull.Value ? null : (DateTime?)r["PaidAt"],
                CreatedAt = (DateTime)r["CreatedAt"]
            };
        }
    }
}
