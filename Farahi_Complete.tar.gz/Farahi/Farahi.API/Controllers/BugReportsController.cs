using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;
using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class BugReportsController : ControllerBase
    {
        // ──────────────────────────────────────────────
        // POST api/bugreports — تقديم بلاغ (أي مستخدم)
        // ──────────────────────────────────────────────
        [HttpPost]
        public IActionResult Create([FromBody] CreateBugReportRequest req)
        {
            if (!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("بيانات غير صالحة"));

            int userId = GetUserId();
            var reportId = Convert.ToInt32(DB.ExecuteScalar(
                @"INSERT INTO BugReports (UserID, Title, Description)
                  OUTPUT INSERTED.ReportID
                  VALUES (@UID, @Title, @Desc)",
                new[]
                {
                    new SqlParameter("@UID", userId),
                    new SqlParameter("@Title", req.Title),
                    new SqlParameter("@Desc", req.Description)
                }));

            return Created("", ApiResponse<object>.Ok(new { ReportID = reportId }, "تم تقديم البلاغ بنجاح"));
        }

        // ──────────────────────────────────────────────
        // GET api/bugreports — كل البلاغات (مدير فقط)
        // ──────────────────────────────────────────────
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult GetAll([FromQuery] string? status)
        {
            string where = "1=1";
            var parms = new List<SqlParameter>();

            if (!string.IsNullOrEmpty(status))
            {
                where += " AND b.Status = @Status";
                parms.Add(new SqlParameter("@Status", status));
            }

            var dt = DB.ExecuteQuery(
                $@"SELECT b.ReportID, b.UserID, u.FirstName + ' ' + u.LastName AS UserName,
                          b.Title, b.Description, b.Status, b.CreatedAt, b.ResolvedAt
                   FROM BugReports b INNER JOIN Users u ON b.UserID = u.UserID
                   WHERE {where}
                   ORDER BY b.CreatedAt DESC",
                parms.ToArray());

            var list = new List<BugReportResponse>();
            foreach (DataRow row in dt.Rows)
                list.Add(MapBugReport(row));

            return Ok(ApiResponse<List<BugReportResponse>>.Ok(list));
        }

        // ──────────────────────────────────────────────
        // GET api/bugreports/my — بلاغاتي
        // ──────────────────────────────────────────────
        [HttpGet("my")]
        public IActionResult GetMine()
        {
            int userId = GetUserId();
            var dt = DB.ExecuteQuery(
                @"SELECT b.ReportID, b.UserID, u.FirstName + ' ' + u.LastName AS UserName,
                         b.Title, b.Description, b.Status, b.CreatedAt, b.ResolvedAt
                  FROM BugReports b INNER JOIN Users u ON b.UserID = u.UserID
                  WHERE b.UserID = @UID ORDER BY b.CreatedAt DESC",
                new[] { new SqlParameter("@UID", userId) });

            var list = new List<BugReportResponse>();
            foreach (DataRow row in dt.Rows) list.Add(MapBugReport(row));

            return Ok(ApiResponse<List<BugReportResponse>>.Ok(list));
        }

        // ──────────────────────────────────────────────
        // PUT api/bugreports/{id}/status — تحديث حالة البلاغ (مدير)
        // ──────────────────────────────────────────────
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/status")]
        public IActionResult UpdateStatus(int id, [FromBody] UpdateBugStatusRequest req)
        {
            if (!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("بيانات غير صالحة"));

            string resolvedSql = req.Status == "Resolved" || req.Status == "Closed" ? ", ResolvedAt = GETDATE()" : "";

            int affected = DB.ExecuteNonQuery(
                $"UPDATE BugReports SET Status = @Status{resolvedSql} WHERE ReportID = @ID",
                new[] { new SqlParameter("@Status", req.Status), new SqlParameter("@ID", id) });

            if (affected == 0) return NotFound(ApiResponse<object>.Fail("البلاغ غير موجود"));

            return Ok(ApiResponse<object>.Ok(null, "تم تحديث الحالة"));
        }

        private int GetUserId() => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        private BugReportResponse MapBugReport(DataRow row) => new()
        {
            ReportID = Convert.ToInt32(row["ReportID"]),
            UserID = Convert.ToInt32(row["UserID"]),
            UserName = row["UserName"].ToString()!,
            Title = row["Title"].ToString()!,
            Description = row["Description"].ToString()!,
            Status = row["Status"].ToString()!,
            CreatedAt = Convert.ToDateTime(row["CreatedAt"]),
            ResolvedAt = row["ResolvedAt"] == DBNull.Value ? null : Convert.ToDateTime(row["ResolvedAt"])
        };
    }
}
