using System.Data; using System.Data.SqlClient; using System.Security.Claims;
using Farahi.API.Helpers; using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController] [Route("api/[controller]")] [Authorize]
    public class DashboardController : ControllerBase
    {
        [Authorize(Roles="Provider")] [HttpGet("provider")]
        public IActionResult Provider()
        {
            int pid=int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            int ts=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Services WHERE ProviderID=@P AND IsActive=1",new[]{new SqlParameter("@P",pid)}));
            var bs=DB.ExecuteQuery(@"SELECT COUNT(*) AS TB,ISNULL(SUM(CASE WHEN b.Status IN('Confirmed','Completed') THEN b.TotalPrice END),0) AS TE,
                COUNT(CASE WHEN b.Status='Confirmed' AND b.EventDate>=CAST(GETDATE() AS DATE) THEN 1 END) AS UB
                FROM Bookings b INNER JOIN Services s ON b.ServiceID=s.ServiceID WHERE s.ProviderID=@P",new[]{new SqlParameter("@P",pid)});
            var rs=DB.ExecuteQuery("SELECT ISNULL(AVG(CAST(r.Rating AS DECIMAL(3,2))),0) AS AR,COUNT(r.ReviewID) AS TR FROM Reviews r INNER JOIN Services s ON r.ServiceID=s.ServiceID WHERE s.ProviderID=@P",new[]{new SqlParameter("@P",pid)});
            var b=bs.Rows[0]; var r=rs.Rows[0];
            return Ok(ApiResponse<ProviderDashboard>.Ok(new(){TotalServices=ts,TotalBookings=(int)b["TB"],TotalEarnings=(decimal)b["TE"],UpcomingBookings=(int)b["UB"],AverageRating=(decimal)r["AR"],TotalReviews=(int)r["TR"]}));
        }

        [Authorize(Roles="Admin")] [HttpGet("admin")]
        public IActionResult Admin()
        {
            return Ok(ApiResponse<AdminDashboard>.Ok(new(){
                TotalUsers=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Users WHERE IsActive=1")),
                TotalProviders=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Users WHERE Role='Provider' AND IsActive=1")),
                TotalCustomers=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Users WHERE Role='Customer' AND IsActive=1")),
                TotalServices=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Services WHERE IsActive=1")),
                PendingApprovals=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Services WHERE IsActive=1 AND IsApproved=0")),
                TotalBookings=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Bookings")),
                TotalRevenue=Convert.ToDecimal(DB.ExecuteScalar("SELECT ISNULL(SUM(TotalPrice),0) FROM Bookings WHERE Status IN('Confirmed','Completed')")),
                OpenBugReports=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM BugReports WHERE Status IN('Open','InProgress')"))
            }));
        }

        // Admin powers: block/unblock user
        [Authorize(Roles="Admin")] [HttpPut("admin/block-user/{userId}")]
        public IActionResult BlockUser(int userId,[FromQuery] bool block=true)
        {
            DB.ExecuteNonQuery("UPDATE Users SET IsActive=@A,UpdatedAt=GETDATE() WHERE UserID=@ID",new[]{new SqlParameter("@A",!block),new SqlParameter("@ID",userId)});
            return Ok(ApiResponse<object>.Ok(null,block?"User blocked":"User unblocked"));
        }

        // Admin: list all users
        [Authorize(Roles="Admin")] [HttpGet("admin/users")]
        public IActionResult AllUsers()
        {
            var dt=DB.ExecuteQuery("SELECT UserID,FirstName,LastName,Email,Phone,Role,IsActive,CreatedAt FROM Users ORDER BY CreatedAt DESC");
            var list=new List<object>();
            foreach(DataRow r in dt.Rows) list.Add(new{UserID=(int)r["UserID"],FirstName=r["FirstName"].ToString(),LastName=r["LastName"].ToString(),Email=r["Email"].ToString(),Phone=r["Phone"]==DBNull.Value?null:r["Phone"].ToString(),Role=r["Role"].ToString(),IsActive=(bool)r["IsActive"],CreatedAt=(DateTime)r["CreatedAt"]});
            return Ok(ApiResponse<List<object>>.Ok(list));
        }
    }
}
