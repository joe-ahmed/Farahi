using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;
using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Customer")]
    public class FavoritesController : ControllerBase
    {
        // ──────────────────────────────────────────────
        // GET api/favorites — خدماتي المفضلة
        // ──────────────────────────────────────────────
        [HttpGet]
        public IActionResult GetMine()
        {
            int userId = GetUserId();
            var dt = DB.ExecuteQuery(
                @"SELECT s.ServiceID, s.Name, s.NameAr, s.City, s.Price, s.AverageRating,
                         (SELECT TOP 1 ImageUrl FROM ServiceImages si WHERE si.ServiceID = s.ServiceID ORDER BY si.DisplayOrder) AS CoverImageUrl,
                         f.CreatedAt AS AddedAt
                  FROM Favorites f
                      INNER JOIN Services s ON f.ServiceID = s.ServiceID
                  WHERE f.UserID = @UID AND s.IsActive = 1
                  ORDER BY f.CreatedAt DESC",
                new[] { new SqlParameter("@UID", userId) });

            var list = new List<FavoriteResponse>();
            foreach (DataRow row in dt.Rows)
                list.Add(new FavoriteResponse
                {
                    ServiceID = Convert.ToInt32(row["ServiceID"]),
                    Name = row["Name"].ToString()!,
                    NameAr = row["NameAr"] == DBNull.Value ? null : row["NameAr"].ToString(),
                    City = row["City"].ToString()!,
                    Price = Convert.ToDecimal(row["Price"]),
                    AverageRating = Convert.ToDecimal(row["AverageRating"]),
                    CoverImageUrl = row["CoverImageUrl"] == DBNull.Value ? null : row["CoverImageUrl"].ToString(),
                    AddedAt = Convert.ToDateTime(row["AddedAt"])
                });

            return Ok(ApiResponse<List<FavoriteResponse>>.Ok(list));
        }

        // ──────────────────────────────────────────────
        // POST api/favorites/{serviceId} — إضافة للمفضلة
        // ──────────────────────────────────────────────
        [HttpPost("{serviceId}")]
        public IActionResult Add(int serviceId)
        {
            int userId = GetUserId();

            var exists = Convert.ToInt32(DB.ExecuteScalar(
                "SELECT COUNT(*) FROM Favorites WHERE UserID = @UID AND ServiceID = @SID",
                new[] { new SqlParameter("@UID", userId), new SqlParameter("@SID", serviceId) }));

            if (exists > 0) return Ok(ApiResponse<object>.Ok(null, "موجودة بالفعل في المفضلة"));

            DB.ExecuteNonQuery(
                "INSERT INTO Favorites (UserID, ServiceID) VALUES (@UID, @SID)",
                new[] { new SqlParameter("@UID", userId), new SqlParameter("@SID", serviceId) });

            return Created("", ApiResponse<object>.Ok(null, "تم إضافتها للمفضلة"));
        }

        // ──────────────────────────────────────────────
        // DELETE api/favorites/{serviceId} — إزالة من المفضلة
        // ──────────────────────────────────────────────
        [HttpDelete("{serviceId}")]
        public IActionResult Remove(int serviceId)
        {
            int userId = GetUserId();
            DB.ExecuteNonQuery(
                "DELETE FROM Favorites WHERE UserID = @UID AND ServiceID = @SID",
                new[] { new SqlParameter("@UID", userId), new SqlParameter("@SID", serviceId) });

            return Ok(ApiResponse<object>.Ok(null, "تم الإزالة من المفضلة"));
        }

        // ──────────────────────────────────────────────
        // GET api/favorites/check/{serviceId} — هل الخدمة مفضلة؟
        // ──────────────────────────────────────────────
        [HttpGet("check/{serviceId}")]
        public IActionResult Check(int serviceId)
        {
            int userId = GetUserId();
            var exists = Convert.ToInt32(DB.ExecuteScalar(
                "SELECT COUNT(*) FROM Favorites WHERE UserID = @UID AND ServiceID = @SID",
                new[] { new SqlParameter("@UID", userId), new SqlParameter("@SID", serviceId) }));

            return Ok(ApiResponse<object>.Ok(new { IsFavorite = exists > 0 }));
        }

        private int GetUserId() => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    }
}
