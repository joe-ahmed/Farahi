using System.Data; using System.Data.SqlClient; using System.Security.Claims;
using Farahi.API.Helpers; using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController] [Route("api/[controller]")] [Authorize]
    public class BookingsController : ControllerBase
    {
        // POST api/bookings — حجز مباشر (Confirmed فوراً)
        [Authorize(Roles="Customer")] [HttpPost]
        public IActionResult Create([FromBody] CreateBookingRequest req)
        {
            if(!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("Invalid"));
            int uid=Uid();
            var svc=DB.ExecuteQuery("SELECT ServiceID,ProviderID,Name,Price FROM Services WHERE ServiceID=@ID AND IsActive=1 AND IsApproved=1",new[]{new SqlParameter("@ID",req.ServiceID)});
            if(svc.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Service not found"));
            decimal price=(decimal)svc.Rows[0]["Price"]; int provId=(int)svc.Rows[0]["ProviderID"]; string svcName=svc.Rows[0]["Name"].ToString()!;
            var eventDate=req.EventDate.Date;

            // تحقق الإتاحة
            var av=DB.ExecuteQuery("SELECT IsAvailable FROM ServiceAvailability WHERE ServiceID=@S AND AvailDate=@D",new[]{new SqlParameter("@S",req.ServiceID),new SqlParameter("@D",eventDate)});
            if(av.Rows.Count>0 && !(bool)av.Rows[0]["IsAvailable"]) return Conflict(ApiResponse<object>.Fail("Date not available"));

            var dup=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM Bookings WHERE ServiceID=@S AND EventDate=@D AND Status IN('Confirmed')",new[]{new SqlParameter("@S",req.ServiceID),new SqlParameter("@D",eventDate)}));
            if(dup>0) return Conflict(ApiResponse<object>.Fail("Date already booked"));

            // حجز مباشر — Confirmed فوراً (مفيش Pending)
            var bid=Convert.ToInt32(DB.ExecuteScalar(@"INSERT INTO Bookings(UserID,ServiceID,EventDate,TotalPrice,Notes,Status,ConfirmedAt,PaymentMethod)
                OUTPUT INSERTED.BookingID VALUES(@U,@S,@D,@P,@N,'Confirmed',GETDATE(),@PM)",
                new[]{new SqlParameter("@U",uid),new SqlParameter("@S",req.ServiceID),new SqlParameter("@D",eventDate),new SqlParameter("@P",price),new SqlParameter("@N",(object?)req.Notes??DBNull.Value),new SqlParameter("@PM",req.PaymentMethod)}));

            // إنشاء سجل الدفع
            string payStatus = req.PaymentMethod == "Cash" ? "Pending" : "Pending";  // كلهم Pending لحد التأكيد
            DB.ExecuteNonQuery(@"INSERT INTO Payments (BookingID, Amount, Method, Status, WalletPhone)
                VALUES (@BID, @Amt, @Method, @Status, @Wallet)",
                new[]{new SqlParameter("@BID",bid),new SqlParameter("@Amt",price),new SqlParameter("@Method",req.PaymentMethod),
                new SqlParameter("@Status",payStatus),new SqlParameter("@Wallet",(object?)req.WalletPhone??DBNull.Value)});

            // حجب التاريخ
            var ex=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM ServiceAvailability WHERE ServiceID=@S AND AvailDate=@D",new[]{new SqlParameter("@S",req.ServiceID),new SqlParameter("@D",eventDate)}));
            if(ex>0) DB.ExecuteNonQuery("UPDATE ServiceAvailability SET IsAvailable=0 WHERE ServiceID=@S AND AvailDate=@D",new[]{new SqlParameter("@S",req.ServiceID),new SqlParameter("@D",eventDate)});
            else DB.ExecuteNonQuery("INSERT INTO ServiceAvailability(ServiceID,AvailDate,IsAvailable) VALUES(@S,@D,0)",new[]{new SqlParameter("@S",req.ServiceID),new SqlParameter("@D",eventDate)});

            // إشعار الطرفين
            var custName=DB.ExecuteScalar("SELECT FirstName+' '+LastName FROM Users WHERE UserID=@ID",new[]{new SqlParameter("@ID",uid)})?.ToString()??"";
            Notify(provId,"Booking Confirmed",$"New booking from {custName} for {svcName} on {eventDate:yyyy-MM-dd}","BookingConfirmed",bid);
            Notify(uid,"Booking Confirmed",$"Your booking for {svcName} on {eventDate:yyyy-MM-dd} is confirmed!","BookingConfirmed",bid);

            return Created("",ApiResponse<object>.Ok(new{BookingID=bid},"Booking confirmed!"));
        }

        [Authorize(Roles="Customer")] [HttpGet("my")]
        public IActionResult MyBookings() => Ok(ApiResponse<List<BookingResponse>>.Ok(Load("b.UserID=@P",new SqlParameter("@P",Uid()))));

        [Authorize(Roles="Provider")] [HttpGet("provider")]
        public IActionResult ProviderBookings() => Ok(ApiResponse<List<BookingResponse>>.Ok(Load("s.ProviderID=@P",new SqlParameter("@P",Uid()))));

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var items=Load("b.BookingID=@P",new SqlParameter("@P",id));
            if(items.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            return Ok(ApiResponse<BookingResponse>.Ok(items[0]));
        }

        [HttpPut("{id}/cancel")]
        public IActionResult Cancel(int id,[FromBody] CancelBookingRequest req)
        {
            int uid=Uid();
            var dt=DB.ExecuteQuery(@"SELECT b.UserID,b.ServiceID,b.EventDate,b.Status,s.ProviderID,s.Name FROM Bookings b INNER JOIN Services s ON b.ServiceID=s.ServiceID WHERE b.BookingID=@ID",new[]{new SqlParameter("@ID",id)});
            if(dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            var r=dt.Rows[0]; int custId=(int)r["UserID"]; int provId=(int)r["ProviderID"];
            if(uid!=custId&&uid!=provId) return Forbid();
            if(r["Status"].ToString()!="Confirmed") return BadRequest(ApiResponse<object>.Fail("Can only cancel confirmed bookings"));

            DB.ExecuteNonQuery("UPDATE Bookings SET Status='Cancelled',CancelledAt=GETDATE(),CancelReason=@R,UpdatedAt=GETDATE() WHERE BookingID=@ID",new[]{new SqlParameter("@R",(object?)req.Reason??DBNull.Value),new SqlParameter("@ID",id)});
            DB.ExecuteNonQuery("UPDATE ServiceAvailability SET IsAvailable=1 WHERE ServiceID=@S AND AvailDate=@D",new[]{new SqlParameter("@S",(int)r["ServiceID"]),new SqlParameter("@D",(DateTime)r["EventDate"])});
            int notifyUser=uid==custId?provId:custId;
            Notify(notifyUser,"Booking Cancelled",$"Booking for {r["Name"]} on {(DateTime)r["EventDate"]:yyyy-MM-dd} was cancelled","BookingCancelled",id);
            return Ok(ApiResponse<object>.Ok(null,"Cancelled"));
        }

        [Authorize(Roles="Provider")] [HttpPut("{id}/complete")]
        public IActionResult Complete(int id)
        {
            int pid=Uid();
            var dt=DB.ExecuteQuery("SELECT b.UserID,b.Status,s.ProviderID,s.Name FROM Bookings b INNER JOIN Services s ON b.ServiceID=s.ServiceID WHERE b.BookingID=@ID",new[]{new SqlParameter("@ID",id)});
            if(dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            if((int)dt.Rows[0]["ProviderID"]!=pid) return Forbid();
            if(dt.Rows[0]["Status"].ToString()!="Confirmed") return BadRequest(ApiResponse<object>.Fail("Must be confirmed first"));
            DB.ExecuteNonQuery("UPDATE Bookings SET Status='Completed',CompletedAt=GETDATE(),UpdatedAt=GETDATE() WHERE BookingID=@ID",new[]{new SqlParameter("@ID",id)});
            Notify((int)dt.Rows[0]["UserID"],"Booking Completed",$"Your booking for {dt.Rows[0]["Name"]} is complete. You can now leave a review!","BookingCompleted",id);
            return Ok(ApiResponse<object>.Ok(null,"Completed"));
        }

        private int Uid()=>int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
        private void Notify(int uid,string t,string m,string ty,int r)=>DB.ExecuteNonQuery("INSERT INTO Notifications(UserID,Title,Message,Type,ReferenceID) VALUES(@U,@T,@M,@Ty,@R)",new[]{new SqlParameter("@U",uid),new SqlParameter("@T",t),new SqlParameter("@M",m),new SqlParameter("@Ty",ty),new SqlParameter("@R",r)});

        private List<BookingResponse> Load(string cond,SqlParameter fp)
        {
            var dt=DB.ExecuteQuery($@"SELECT b.BookingID,b.UserID,cu.FirstName+' '+cu.LastName AS CustomerName,cu.Phone AS CustomerPhone,
                b.ServiceID,s.Name AS ServiceName,s.NameAr AS ServiceNameAr,s.City AS ServiceCity,pu.FirstName+' '+pu.LastName AS ProviderName,c.Name AS CategoryName,
                b.EventDate,b.BookingDate,b.Status,b.TotalPrice,b.Notes,b.CancelReason,b.ConfirmedAt,b.CompletedAt,b.CancelledAt,
                CASE WHEN EXISTS(SELECT 1 FROM Reviews r WHERE r.BookingID=b.BookingID) THEN 1 ELSE 0 END AS HasReview
                FROM Bookings b INNER JOIN Users cu ON b.UserID=cu.UserID INNER JOIN Services s ON b.ServiceID=s.ServiceID
                INNER JOIN Users pu ON s.ProviderID=pu.UserID INNER JOIN ServiceCategories c ON s.CategoryID=c.CategoryID
                WHERE {cond} ORDER BY b.EventDate DESC",new[]{fp});
            var list=new List<BookingResponse>();
            foreach(DataRow r in dt.Rows) list.Add(new(){BookingID=(int)r["BookingID"],UserID=(int)r["UserID"],CustomerName=r["CustomerName"].ToString()!,
                CustomerPhone=r["CustomerPhone"]==DBNull.Value?null:r["CustomerPhone"].ToString(),ServiceID=(int)r["ServiceID"],ServiceName=r["ServiceName"].ToString()!,
                ServiceNameAr=r["ServiceNameAr"]==DBNull.Value?null:r["ServiceNameAr"].ToString(),ServiceCity=r["ServiceCity"].ToString()!,
                ProviderName=r["ProviderName"].ToString()!,CategoryName=r["CategoryName"].ToString()!,EventDate=(DateTime)r["EventDate"],BookingDate=(DateTime)r["BookingDate"],
                Status=r["Status"].ToString()!,TotalPrice=(decimal)r["TotalPrice"],Notes=r["Notes"]==DBNull.Value?null:r["Notes"].ToString(),
                CancelReason=r["CancelReason"]==DBNull.Value?null:r["CancelReason"].ToString(),
                ConfirmedAt=r["ConfirmedAt"]==DBNull.Value?null:(DateTime?)r["ConfirmedAt"],CompletedAt=r["CompletedAt"]==DBNull.Value?null:(DateTime?)r["CompletedAt"],
                CancelledAt=r["CancelledAt"]==DBNull.Value?null:(DateTime?)r["CancelledAt"],HasReview=(bool)r["HasReview"]});
            return list;
        }
    }
}
