using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;
using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ServicesController : ControllerBase
    {
        private readonly Farahi.API.Services.EmailService _email;
        public ServicesController(Farahi.API.Services.EmailService email) => _email = email;
        [HttpGet]
        public IActionResult Browse([FromQuery] ServiceFilterRequest filter)
        {
            var conds = new List<string> { "s.IsActive = 1", "s.IsApproved = 1" };
            var parms = new List<SqlParameter>();
            if (filter.CategoryID.HasValue) { conds.Add("s.CategoryID = @CatID"); parms.Add(new("@CatID", filter.CategoryID.Value)); }
            if (!string.IsNullOrEmpty(filter.City)) { conds.Add("s.City = @City"); parms.Add(new("@City", filter.City)); }
            if (filter.MinPrice.HasValue) { conds.Add("s.Price >= @MinP"); parms.Add(new("@MinP", filter.MinPrice.Value)); }
            if (filter.MaxPrice.HasValue) { conds.Add("s.Price <= @MaxP"); parms.Add(new("@MaxP", filter.MaxPrice.Value)); }
            if (filter.MinCapacity.HasValue) { conds.Add("s.Capacity >= @MinC"); parms.Add(new("@MinC", filter.MinCapacity.Value)); }

            string where = string.Join(" AND ", conds);
            string orderBy = filter.SortBy switch { "price_asc" => "s.Price ASC", "price_desc" => "s.Price DESC", "newest" => "s.CreatedAt DESC", _ => "s.AverageRating DESC" };
            int offset = (filter.Page - 1) * filter.PageSize;

            int total = Convert.ToInt32(DB.ExecuteScalar($"SELECT COUNT(*) FROM Services s WHERE {where}", parms.ToArray()));
            var p2 = new List<SqlParameter>(parms) { new("@Off", offset), new("@PS", filter.PageSize) };
            var dt = DB.ExecuteQuery($@"SELECT s.ServiceID, s.Name, s.NameAr, s.City, s.Price, s.Capacity, s.AverageRating, s.ReviewCount,
                s.CategoryID, c.Name AS CategoryName, c.NameAr AS CategoryNameAr, u.FirstName+' '+u.LastName AS ProviderName,
                (SELECT TOP 1 ImageUrl FROM ServiceImages si WHERE si.ServiceID=s.ServiceID ORDER BY si.DisplayOrder) AS CoverImageUrl
                FROM Services s INNER JOIN ServiceCategories c ON s.CategoryID=c.CategoryID INNER JOIN Users u ON s.ProviderID=u.UserID
                WHERE {where} ORDER BY {orderBy} OFFSET @Off ROWS FETCH NEXT @PS ROWS ONLY", p2.ToArray());
            var items = new List<ServiceListItem>();
            foreach (DataRow r in dt.Rows) items.Add(Map(r));
            return Ok(ApiResponse<PagedResult<ServiceListItem>>.Ok(new() { Items = items, TotalCount = total, Page = filter.Page, PageSize = filter.PageSize }));
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var dt = DB.ExecuteQuery(@"SELECT s.*, c.Name AS CategoryName, c.NameAr AS CategoryNameAr,
                u.FirstName+' '+u.LastName AS ProviderName, u.Phone AS ProviderPhone
                FROM Services s INNER JOIN ServiceCategories c ON s.CategoryID=c.CategoryID INNER JOIN Users u ON s.ProviderID=u.UserID
                WHERE s.ServiceID=@ID AND s.IsActive=1", new[] { new SqlParameter("@ID", id) });
            if (dt.Rows.Count == 0) return NotFound(ApiResponse<object>.Fail("Service not found"));
            var row = dt.Rows[0];
            var d = new ServiceDetail {
                ServiceID = (int)row["ServiceID"], ProviderID = (int)row["ProviderID"],
                ProviderName = row["ProviderName"].ToString()!, ProviderPhone = row["ProviderPhone"]==DBNull.Value?null:row["ProviderPhone"].ToString(),
                ServicePhone = row["Phone"]==DBNull.Value?null:row["Phone"].ToString(),
                CategoryID = (int)row["CategoryID"], CategoryName = row["CategoryName"].ToString()!,
                CategoryNameAr = row["CategoryNameAr"]==DBNull.Value?null:row["CategoryNameAr"].ToString(),
                Name = row["Name"].ToString()!, NameAr = row["NameAr"]==DBNull.Value?null:row["NameAr"].ToString(),
                Description = row["Description"]==DBNull.Value?null:row["Description"].ToString(),
                DescriptionAr = row["DescriptionAr"]==DBNull.Value?null:row["DescriptionAr"].ToString(),
                City = row["City"].ToString()!, Address = row["Address"]==DBNull.Value?null:row["Address"].ToString(),
                Latitude = row["Latitude"]==DBNull.Value?null:(decimal?)row["Latitude"], Longitude = row["Longitude"]==DBNull.Value?null:(decimal?)row["Longitude"],
                Price = (decimal)row["Price"], Capacity = row["Capacity"]==DBNull.Value?null:(int?)row["Capacity"],
                AverageRating = (decimal)row["AverageRating"], ReviewCount = (int)row["ReviewCount"],
                IsApproved = (bool)row["IsApproved"], CreatedAt = (DateTime)row["CreatedAt"]
            };
            var imgs = DB.ExecuteQuery("SELECT ImageID,ImageUrl,DisplayOrder,AltText FROM ServiceImages WHERE ServiceID=@ID ORDER BY DisplayOrder", new[]{new SqlParameter("@ID",id)});
            foreach(DataRow i in imgs.Rows) d.Images.Add(new(){ImageID=(int)i["ImageID"],ImageUrl=i["ImageUrl"].ToString()!,DisplayOrder=(int)i["DisplayOrder"],AltText=i["AltText"]==DBNull.Value?null:i["AltText"].ToString()});
            var ams = DB.ExecuteQuery("SELECT a.AmenityID,a.Name,a.NameAr FROM Amenities a INNER JOIN ServiceAmenities sa ON a.AmenityID=sa.AmenityID WHERE sa.ServiceID=@ID", new[]{new SqlParameter("@ID",id)});
            foreach(DataRow a in ams.Rows) d.Amenities.Add(new(){AmenityID=(int)a["AmenityID"],Name=a["Name"].ToString()!,NameAr=a["NameAr"]==DBNull.Value?null:a["NameAr"].ToString()});
            return Ok(ApiResponse<ServiceDetail>.Ok(d));
        }

        [HttpGet("{id}/contact")]
        public IActionResult GetContact(int id)
        {
            var dt = DB.ExecuteQuery(@"SELECT s.Phone AS ServicePhone, u.Phone AS ProviderPhone, u.Email, u.FirstName+' '+u.LastName AS Name
                FROM Services s INNER JOIN Users u ON s.ProviderID=u.UserID WHERE s.ServiceID=@ID AND s.IsActive=1", new[]{new SqlParameter("@ID",id)});
            if (dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            var r = dt.Rows[0];
            return Ok(ApiResponse<object>.Ok(new { ProviderName=r["Name"].ToString(), ServicePhone=r["ServicePhone"]==DBNull.Value?null:r["ServicePhone"].ToString(), ProviderPhone=r["ProviderPhone"]==DBNull.Value?null:r["ProviderPhone"].ToString(), ProviderEmail=r["Email"].ToString() }));
        }

        [Authorize(Roles="Provider")] [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateServiceRequest req)
        {
            if(!ModelState.IsValid) return BadRequest(ApiResponse<object>.Fail("Invalid data"));
            int pid = Uid(); string code = new Random().Next(100000,999999).ToString();
            var sid = Convert.ToInt32(DB.ExecuteScalar(@"INSERT INTO Services(ProviderID,CategoryID,Name,NameAr,Description,DescriptionAr,City,Address,Latitude,Longitude,Price,Capacity,Phone,IsApproved,VerificationCode,VerificationCodeExpiry)
                OUTPUT INSERTED.ServiceID VALUES(@P,@C,@N,@NA,@D,@DA,@Ci,@A,@La,@Lo,@Pr,@Ca,@Ph,0,@Co,DATEADD(HOUR,24,GETDATE()))",
                new[]{new SqlParameter("@P",pid),new SqlParameter("@C",req.CategoryID),new SqlParameter("@N",req.Name),new SqlParameter("@NA",(object?)req.NameAr??DBNull.Value),
                new SqlParameter("@D",(object?)req.Description??DBNull.Value),new SqlParameter("@DA",(object?)req.DescriptionAr??DBNull.Value),
                new SqlParameter("@Ci",req.City),new SqlParameter("@A",(object?)req.Address??DBNull.Value),
                new SqlParameter("@La",(object?)req.Latitude??DBNull.Value),new SqlParameter("@Lo",(object?)req.Longitude??DBNull.Value),
                new SqlParameter("@Pr",req.Price),new SqlParameter("@Ca",(object?)req.Capacity??DBNull.Value),
                new SqlParameter("@Ph",(object?)req.Phone??DBNull.Value),new SqlParameter("@Co",code)}));
            if(req.ImageUrls!=null) for(int i=0;i<req.ImageUrls.Count;i++) DB.ExecuteNonQuery("INSERT INTO ServiceImages(ServiceID,ImageUrl,DisplayOrder)VALUES(@S,@U,@O)",new[]{new SqlParameter("@S",sid),new SqlParameter("@U",req.ImageUrls[i]),new SqlParameter("@O",i)});
            if(req.AmenityIDs!=null) foreach(int a in req.AmenityIDs) DB.ExecuteNonQuery("INSERT INTO ServiceAmenities(ServiceID,AmenityID)VALUES(@S,@A)",new[]{new SqlParameter("@S",sid),new SqlParameter("@A",a)});

            // إرسال كود التحقق بالإيميل لمقدم الخدمة
            var provEmail = DB.ExecuteScalar("SELECT Email FROM Users WHERE UserID=@ID", new[]{new SqlParameter("@ID",pid)})?.ToString();
            if (!string.IsNullOrEmpty(provEmail))
            {
                try { await _email.SendServiceVerificationCode(provEmail, code, req.Name); }
                catch (Exception ex) { Console.WriteLine($"⚠️ Email failed: {ex.Message}"); }
            }

            return Created("",ApiResponse<object>.Ok(new{ServiceID=sid,VerificationCode=code},"Service created. Check your email for the verification code."));
        }

        [Authorize(Roles="Provider")] [HttpPost("{id}/verify")]
        public IActionResult Verify(int id,[FromBody] VerifyCodeRequest req)
        {
            int pid=Uid();
            var dt=DB.ExecuteQuery("SELECT VerificationCode,VerificationCodeExpiry,ProviderID FROM Services WHERE ServiceID=@ID AND IsActive=1",new[]{new SqlParameter("@ID",id)});
            if(dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            if((int)dt.Rows[0]["ProviderID"]!=pid) return Forbid();
            if(dt.Rows[0]["VerificationCode"]?.ToString()!=req.Code) return BadRequest(ApiResponse<object>.Fail("Wrong code"));
            if(dt.Rows[0]["VerificationCodeExpiry"]!=DBNull.Value && DateTime.Now>(DateTime)dt.Rows[0]["VerificationCodeExpiry"]) return BadRequest(ApiResponse<object>.Fail("Code expired"));
            DB.ExecuteNonQuery("UPDATE Services SET IsApproved=1,VerificationCode=NULL,UpdatedAt=GETDATE() WHERE ServiceID=@ID",new[]{new SqlParameter("@ID",id)});
            return Ok(ApiResponse<object>.Ok(null,"Service verified and live!"));
        }

        [Authorize(Roles="Provider")] [HttpPut("{id}")]
        public IActionResult Update(int id,[FromBody] UpdateServiceRequest req)
        {
            int pid=Uid(); var o=DB.ExecuteScalar("SELECT ProviderID FROM Services WHERE ServiceID=@ID AND IsActive=1",new[]{new SqlParameter("@ID",id)});
            if(o==null) return NotFound(ApiResponse<object>.Fail("Not found")); if((int)o!=pid) return Forbid();
            var s=new List<string>(); var p=new List<SqlParameter>{new("@ID",id)};
            if(req.Name!=null){s.Add("Name=@N");p.Add(new("@N",req.Name));} if(req.NameAr!=null){s.Add("NameAr=@NA");p.Add(new("@NA",req.NameAr));}
            if(req.Description!=null){s.Add("Description=@D");p.Add(new("@D",req.Description));} if(req.City!=null){s.Add("City=@C");p.Add(new("@C",req.City));}
            if(req.Price.HasValue){s.Add("Price=@P");p.Add(new("@P",req.Price.Value));} if(req.Capacity.HasValue){s.Add("Capacity=@Ca");p.Add(new("@Ca",req.Capacity.Value));}
            if(s.Count>0){s.Add("UpdatedAt=GETDATE()");DB.ExecuteNonQuery($"UPDATE Services SET {string.Join(",",s)} WHERE ServiceID=@ID",p.ToArray());}
            return Ok(ApiResponse<object>.Ok(null,"Updated"));
        }

        [Authorize(Roles="Provider,Admin")] [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            int uid=Uid(); string role=User.FindFirst(ClaimTypes.Role)!.Value;
            var dt=DB.ExecuteQuery("SELECT ProviderID FROM Services WHERE ServiceID=@ID AND IsActive=1",new[]{new SqlParameter("@ID",id)});
            if(dt.Rows.Count==0) return NotFound(ApiResponse<object>.Fail("Not found"));
            if(role!="Admin"&&(int)dt.Rows[0]["ProviderID"]!=uid) return Forbid();
            DB.ExecuteNonQuery("UPDATE Services SET IsActive=0,UpdatedAt=GETDATE() WHERE ServiceID=@ID",new[]{new SqlParameter("@ID",id)});
            return Ok(ApiResponse<object>.Ok(null,"Deleted"));
        }

        [Authorize(Roles="Provider")] [HttpGet("my")]
        public IActionResult MyServices()
        {
            var dt=DB.ExecuteQuery(@"SELECT s.ServiceID,s.Name,s.NameAr,s.City,s.Price,s.Capacity,s.AverageRating,s.ReviewCount,s.CategoryID,s.IsApproved,
                c.Name AS CategoryName,c.NameAr AS CategoryNameAr,u.FirstName+' '+u.LastName AS ProviderName,
                (SELECT TOP 1 ImageUrl FROM ServiceImages si WHERE si.ServiceID=s.ServiceID ORDER BY si.DisplayOrder) AS CoverImageUrl
                FROM Services s INNER JOIN ServiceCategories c ON s.CategoryID=c.CategoryID INNER JOIN Users u ON s.ProviderID=u.UserID
                WHERE s.ProviderID=@P AND s.IsActive=1 ORDER BY s.CreatedAt DESC",new[]{new SqlParameter("@P",Uid())});
            var items=new List<ServiceListItem>(); foreach(DataRow r in dt.Rows) items.Add(Map(r));
            return Ok(ApiResponse<List<ServiceListItem>>.Ok(items));
        }

        [HttpGet("{id}/reviews")]
        public IActionResult GetReviews(int id)
        {
            var dt=DB.ExecuteQuery(@"SELECT r.ReviewID,r.UserID,u.FirstName+' '+u.LastName AS CustomerName,u.ProfileImageUrl,r.Rating,r.Comment,r.CreatedAt
                FROM Reviews r INNER JOIN Users u ON r.UserID=u.UserID WHERE r.ServiceID=@ID ORDER BY r.CreatedAt DESC",new[]{new SqlParameter("@ID",id)});
            var list=new List<ReviewResponse>();
            foreach(DataRow r in dt.Rows) list.Add(new(){ReviewID=(int)r["ReviewID"],UserID=(int)r["UserID"],CustomerName=r["CustomerName"].ToString()!,
                ProfileImageUrl=r["ProfileImageUrl"]==DBNull.Value?null:r["ProfileImageUrl"].ToString(),Rating=(int)r["Rating"],
                Comment=r["Comment"]==DBNull.Value?null:r["Comment"].ToString(),CreatedAt=(DateTime)r["CreatedAt"]});
            return Ok(ApiResponse<List<ReviewResponse>>.Ok(list));
        }

        [HttpGet("{id}/availability")]
        public IActionResult GetAvailability(int id,[FromQuery] string? month)
        {
            DateTime s,e; if(!string.IsNullOrEmpty(month)&&DateTime.TryParse(month+"-01",out var p)){s=p;e=p.AddMonths(1).AddDays(-1);}else{s=DateTime.Today;e=DateTime.Today.AddDays(30);}
            var dt=DB.ExecuteQuery("SELECT AvailDate,IsAvailable,Notes FROM ServiceAvailability WHERE ServiceID=@ID AND AvailDate BETWEEN @S AND @E ORDER BY AvailDate",
                new[]{new SqlParameter("@ID",id),new SqlParameter("@S",s),new SqlParameter("@E",e)});
            var list=new List<AvailabilityResponse>(); foreach(DataRow r in dt.Rows) list.Add(new(){Date=(DateTime)r["AvailDate"],IsAvailable=(bool)r["IsAvailable"],Notes=r["Notes"]==DBNull.Value?null:r["Notes"].ToString()});
            return Ok(ApiResponse<List<AvailabilityResponse>>.Ok(list));
        }

        [Authorize(Roles="Provider")] [HttpPost("{id}/availability")]
        public IActionResult SetAvailability(int id,[FromBody] SetAvailabilityRequest req)
        {
            int pid=Uid(); var o=DB.ExecuteScalar("SELECT ProviderID FROM Services WHERE ServiceID=@ID AND IsActive=1",new[]{new SqlParameter("@ID",id)});
            if(o==null) return NotFound(ApiResponse<object>.Fail("Not found")); if((int)o!=pid) return Forbid();
            var date=req.Date.Date; var ex=Convert.ToInt32(DB.ExecuteScalar("SELECT COUNT(*) FROM ServiceAvailability WHERE ServiceID=@S AND AvailDate=@D",new[]{new SqlParameter("@S",id),new SqlParameter("@D",date)}));
            if(ex>0) DB.ExecuteNonQuery("UPDATE ServiceAvailability SET IsAvailable=@A,Notes=@N WHERE ServiceID=@S AND AvailDate=@D",new[]{new SqlParameter("@A",req.IsAvailable),new SqlParameter("@N",(object?)req.Notes??DBNull.Value),new SqlParameter("@S",id),new SqlParameter("@D",date)});
            else DB.ExecuteNonQuery("INSERT INTO ServiceAvailability(ServiceID,AvailDate,IsAvailable,Notes) VALUES(@S,@D,@A,@N)",new[]{new SqlParameter("@S",id),new SqlParameter("@D",date),new SqlParameter("@A",req.IsAvailable),new SqlParameter("@N",(object?)req.Notes??DBNull.Value)});
            return Ok(ApiResponse<object>.Ok(null,"Updated"));
        }

        private int Uid()=>int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
        private ServiceListItem Map(DataRow r)=>new(){ServiceID=(int)r["ServiceID"],Name=r["Name"].ToString()!,NameAr=r["NameAr"]==DBNull.Value?null:r["NameAr"].ToString(),City=r["City"].ToString()!,Price=(decimal)r["Price"],Capacity=r["Capacity"]==DBNull.Value?null:(int?)r["Capacity"],AverageRating=(decimal)r["AverageRating"],ReviewCount=(int)r["ReviewCount"],CategoryID=(int)r["CategoryID"],CategoryName=r["CategoryName"].ToString()!,CategoryNameAr=r["CategoryNameAr"]==DBNull.Value?null:r["CategoryNameAr"].ToString(),ProviderName=r["ProviderName"].ToString()!,CoverImageUrl=r["CoverImageUrl"]==DBNull.Value?null:r["CoverImageUrl"].ToString()};
    }
}
