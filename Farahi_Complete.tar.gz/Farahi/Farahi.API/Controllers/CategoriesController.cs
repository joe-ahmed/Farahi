using Farahi.API.Helpers;
using Farahi.API.Models;
using Microsoft.AspNetCore.Mvc;

namespace Farahi.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : ControllerBase
    {
        // ──────────────────────────────────────────────
        // GET api/categories — كل الفئات مع عدد الخدمات
        // ──────────────────────────────────────────────
        [HttpGet]
        public IActionResult GetAll()
        {
            var dt = DB.ExecuteQuery(
                @"SELECT c.CategoryID, c.Name, c.NameAr, c.Description, c.DescriptionAr, c.IconUrl,
                         (SELECT COUNT(*) FROM Services s WHERE s.CategoryID = c.CategoryID AND s.IsActive = 1 AND s.IsApproved = 1) AS ServiceCount
                  FROM ServiceCategories c
                  WHERE c.IsActive = 1
                  ORDER BY c.DisplayOrder");

            var list = new List<CategoryResponse>();
            foreach (System.Data.DataRow row in dt.Rows)
            {
                list.Add(new CategoryResponse
                {
                    CategoryID = Convert.ToInt32(row["CategoryID"]),
                    Name = row["Name"].ToString()!,
                    NameAr = row["NameAr"] == DBNull.Value ? null : row["NameAr"].ToString(),
                    Description = row["Description"] == DBNull.Value ? null : row["Description"].ToString(),
                    DescriptionAr = row["DescriptionAr"] == DBNull.Value ? null : row["DescriptionAr"].ToString(),
                    IconUrl = row["IconUrl"] == DBNull.Value ? null : row["IconUrl"].ToString(),
                    ServiceCount = Convert.ToInt32(row["ServiceCount"])
                });
            }

            return Ok(ApiResponse<List<CategoryResponse>>.Ok(list));
        }

        // ──────────────────────────────────────────────
        // GET api/categories/{id} — فئة واحدة
        // ──────────────────────────────────────────────
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var dt = DB.ExecuteQuery(
                @"SELECT c.CategoryID, c.Name, c.NameAr, c.Description, c.DescriptionAr, c.IconUrl,
                         (SELECT COUNT(*) FROM Services s WHERE s.CategoryID = c.CategoryID AND s.IsActive = 1 AND s.IsApproved = 1) AS ServiceCount
                  FROM ServiceCategories c
                  WHERE c.CategoryID = @ID AND c.IsActive = 1",
                new[] { new System.Data.SqlClient.SqlParameter("@ID", id) });

            if (dt.Rows.Count == 0)
                return NotFound(ApiResponse<object>.Fail("الفئة غير موجودة"));

            var row = dt.Rows[0];
            return Ok(ApiResponse<CategoryResponse>.Ok(new CategoryResponse
            {
                CategoryID = Convert.ToInt32(row["CategoryID"]),
                Name = row["Name"].ToString()!,
                NameAr = row["NameAr"] == DBNull.Value ? null : row["NameAr"].ToString(),
                Description = row["Description"] == DBNull.Value ? null : row["Description"].ToString(),
                DescriptionAr = row["DescriptionAr"] == DBNull.Value ? null : row["DescriptionAr"].ToString(),
                IconUrl = row["IconUrl"] == DBNull.Value ? null : row["IconUrl"].ToString(),
                ServiceCount = Convert.ToInt32(row["ServiceCount"])
            }));
        }
    }
}
