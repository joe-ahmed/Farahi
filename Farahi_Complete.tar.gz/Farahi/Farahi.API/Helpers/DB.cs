using System.Data;
using System.Data.SqlClient;

namespace Farahi.API.Helpers
{
    public static class DB
    {
        private static string _connStr = "";

        public static void Initialize(string connectionString) => _connStr = connectionString;

        public static SqlConnection GetConnection() => new SqlConnection(_connStr);

        public static DataTable ExecuteQuery(string sql, SqlParameter[]? parameters = null)
        {
            DataTable dt = new DataTable();
            using var conn = GetConnection();
            using var cmd = new SqlCommand(sql, conn);
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            new SqlDataAdapter(cmd).Fill(dt);
            return dt;
        }

        public static int ExecuteNonQuery(string sql, SqlParameter[]? parameters = null)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand(sql, conn);
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteNonQuery();
        }

        public static object? ExecuteScalar(string sql, SqlParameter[]? parameters = null)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand(sql, conn);
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteScalar();
        }
    }
}
