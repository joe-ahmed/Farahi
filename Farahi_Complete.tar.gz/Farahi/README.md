# فرحي — Farahi

## التشغيل المحلي (٣ نوافذ Terminal)

### النافذة ١: قاعدة البيانات
1. افتح **SSMS**
2. افتح ملف `FarahiDB_Final.sql`
3. اضغط **F5** (يتشغل أي عدد مرات بدون أخطاء)

### النافذة ٢: الـ Backend (C# API)
```
cd Farahi.API
dotnet restore
dotnet run
```
يشتغل على: `https://localhost:5001`
Swagger: `https://localhost:5001/swagger`

### النافذة ٣: الـ Frontend (React)
```
cd Farahi.Web
npm install
npm run dev
```
يشتغل على: `http://localhost:5173`

### افتح في المتصفح
```
http://localhost:5173
```

---

## حسابات تجريبية

| الإيميل | كلمة المرور | الدور |
|---|---|---|
| admin@farahi.com | Admin@123 | مدير |
| ahmed@example.com | Ahmed@123 | مقدم خدمة |
| fatma@example.com | Fatma@123 | مقدم خدمة |
| omar@example.com | Omar@123 | عميل |
| sara@example.com | Sara@123 | عميل |

---

## هيكل المشروع

```
Farahi/
├── FarahiDB_Final.sql          ← قاعدة البيانات (شغّلها أولاً)
├── Farahi.sln                  ← Solution file
│
├── Farahi.API/                 ← Backend (C# ASP.NET)
│   ├── Controllers/            ← 10 controllers, 41 endpoint
│   │   ├── AuthController.cs
│   │   ├── ServicesController.cs
│   │   ├── BookingsController.cs
│   │   ├── ReviewsController.cs
│   │   ├── CategoriesController.cs
│   │   ├── AmenitiesController.cs
│   │   ├── NotificationsController.cs
│   │   ├── FavoritesController.cs
│   │   ├── BugReportsController.cs
│   │   └── DashboardController.cs
│   ├── Helpers/DB.cs
│   ├── Models/
│   ├── Services/JwtService.cs
│   └── appsettings.json
│
├── Farahi.Web/                 ← Frontend (React + Vite)
│   ├── src/App.jsx             ← التطبيق كامل
│   ├── src/main.jsx
│   ├── vite.config.js          ← proxy: /api → https://localhost:5001
│   └── package.json
│
└── Farahi.Tests/               ← 45 اختبار
    ├── AuthTests.cs
    ├── ServicesTests.cs
    └── BookingsTests.cs
```

---

## كيف الـ Frontend بيتكلم مع الـ Backend

الـ Frontend بيشتغل على `localhost:5173` والـ Backend على `localhost:5001`.
ملف `vite.config.js` فيه proxy بيحول أي request على `/api/*` تلقائياً للـ Backend:

```
Frontend (5173) → /api/auth/login → Vite Proxy → https://localhost:5001/api/auth/login → Backend
```

يعني في الكود بنكتب:
```js
fetch("/api/auth/login", { ... })  // بدون hostname
```
والـ Vite بيوصلها للـ Backend لوحده. مفيش مشاكل CORS في التطوير.
